package com.example.agro;

public class Database_orders {

    private String oname;
    private String oprice;
    private String ototal;
    private String oseller;
    private String obuyerid;
    private String oqua_req;
    private String oquantity;
    private String oimageId;
    private String address;
    private String oimage_address;
    private String uid;

    public Database_orders(){}

    public Database_orders(String O_name,String O_price,String O_Total,String OQua_req,String O_quantity,String O_seller,String O_buyerid,String OImageId,String Address,String O_imageAddress,String Uid) {
        oname=O_name;
        oprice=O_price;
        ototal=O_Total;
        oseller=O_seller;
        obuyerid=O_buyerid;
        oquantity=O_quantity;
        oimageId=OImageId;
        oqua_req=OQua_req;
        address=Address;
        oimage_address=O_imageAddress;
        uid=Uid;
    }

    public String getOname() {
        return oname;
    }

    public void setOname(String O_name) {
        oname = O_name;
    }

    public String getOprice() {
        return oprice;
    }

    public void setOprice(String O_price) {
        oprice = O_price;
    }

    public String getOtotal() {
        return ototal;
    }

    public void setOtotal(String O_Total) {
        ototal = O_Total;
    }

    public String getOquantity() {return oquantity;}

    public void setOquantity(String O_quantity) {
        oquantity = O_quantity;
    }

    public String getOseller() {
        return oseller;
    }

    public void setOseller(String O_seller) {
        oseller = O_seller;
    }

    public String getObuyerid() {
        return obuyerid;
    }

    public void setObuyerid(String O_buyerid) {
        obuyerid = O_buyerid;
    }

    public String getOqua_req() {return oqua_req;}

    public void setOqua_req(String OQua_req) {oqua_req = OQua_req; }

    public String getOimageId() {return oimageId; }

    public void setOimageId(String OImageId) { oimageId = OImageId; }

    public String getAddress() {
        return address;
    }

    public void setAddress(String Address) {
        address = Address;
    }

    public String getOimage_address() {return oimage_address; }

    public void setOimage_address(String O_imageAddress) { oimage_address = O_imageAddress; }

    public String getUid() {
        return uid;
    }

    public void setUid(String Uid) {
        uid = Uid;
    }
}
