package com.example.agro;

public class Database_Address {
    String houseno,area,city,state,landmark,pincode,latitude,longitude,uid;
    public Database_Address() {
    }
    public Database_Address(String Houseno,String Area,String City,String State,String Landmark,String Pincode,String Latitude,String Longitude,String Uid) {
        houseno=Houseno;
        area=Area;
        city=City;
        state=State;
        landmark=Landmark;
        pincode=Pincode;
        latitude=Latitude;
        longitude=Longitude;
        uid=Uid;
    }

    public String getHouseno() {
        return houseno;
    }

    public void setHouseno(String Houseno) {
        houseno = Houseno;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String Area) {
        area = Area;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String City) {
        city = City;
    }

    public String getState() {
        return state;
    }

    public void setState(String State) {
        state = State;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String Landmark) {
        landmark = Landmark;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String Pincode) {
        pincode = Pincode;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String Latitude) { latitude = Latitude; }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String Longitude) { longitude = Longitude; }

    public String getUid() {
        return uid;
    }

    public void setUid(String Uid) {
        uid = Uid;
    }
}
