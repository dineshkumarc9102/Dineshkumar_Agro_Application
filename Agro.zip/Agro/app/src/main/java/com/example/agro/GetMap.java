package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class GetMap extends AppCompatActivity {

    Button GotoMap;
    DatabaseReference reference,ref_address;
    FirebaseUser user;
    String name,password,category,mobileno,email,UID;
    FirebaseAuth lAuth;
    TextView Name,Password,Category,Mobile,EMail;
    int flag=0;
    ProgressBar progressBarGetMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.get_map);

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference().child("User");
        ref_address= FirebaseDatabase.getInstance().getReference().child("Address");

        GotoMap=(Button)findViewById(R.id.gotoMap);

        Name=(TextView)findViewById(R.id.con_name);
        Password=(TextView)findViewById(R.id.con_password);
        Category=(TextView)findViewById(R.id.con_category);
        Mobile=(TextView)findViewById(R.id.con_Mobile);
        EMail=(TextView)findViewById(R.id.con_email);

        progressBarGetMap=(ProgressBar)findViewById(R.id.progressBar_getMap);

        ref_address.child(user.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    flag=1;
                    GotoMap.setText("Next");
                }
                else {
                    flag=0;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), "Data not fetched.....", Toast.LENGTH_SHORT).show();
            }
        });

        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    name = dataSnapshot.child("name").getValue().toString();
                    email = dataSnapshot.child("email").getValue().toString();
                    category = dataSnapshot.child("category").getValue().toString();
                    mobileno = dataSnapshot.child("mobileno").getValue().toString();

                    Intent newpass=getIntent();
                    password=newpass.getStringExtra("NewPassword");

                    Name.setText(name);
                    Password.setText(password);
                    EMail.setText(email);
                    Category.setText(category);
                    Mobile.setText(mobileno);
                    progressBarGetMap.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"Data not fetched.....",Toast.LENGTH_LONG).show();

            }
        });

        GotoMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                UID = lAuth.getUid();
                name = Name.getText().toString();
                password=Password.getText().toString();
                mobileno = Mobile.getText().toString();
                category = Category.getText().toString();
                email = EMail.getText().toString();

                if (password.equals("")) {
                }
                else {
                    User mUser = new User(name, password, mobileno, email, category, UID);
                    reference.child(UID).setValue(mUser).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {

                            } else {
                                Toast.makeText(getApplicationContext(), "Error..." + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }

                if (flag==0) {
                    Intent loc = new Intent(getApplicationContext(), MapsActivity.class);
                    startActivity(loc);
                    finish();
                }
                else if (flag==1){
                    NextPage();
                }
            }
        });

    }
    public void NextPage(){
        category = Category.getText().toString();
        if (category.equals("Farmer")) {
            Toast.makeText(getApplicationContext(), "WELCOME TO AGRO....." + category, Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(), Mainpage.class);
            startActivity(i);
            finish();
            //progressBar.setVisibility(View.GONE);
        } else if (category.equals("General User")) {
            Toast.makeText(getApplicationContext(), "WELCOME TO AGRO....." + category, Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(), GeneralUser_main.class);
            startActivity(i);
            finish();
            //progressBar.setVisibility(View.GONE);
        } else if (category.equals("Retailer/Hotels")) {
            Toast.makeText(getApplicationContext(), "WELCOME TO AGRO....." + category, Toast.LENGTH_SHORT).show();
            Intent i = new Intent(getApplicationContext(), Retailer_main.class);
            startActivity(i);
            finish();
            //progressBar.setVisibility(View.GONE);
        }
    }
}