package com.example.agro;

public class Database_CropTips {

    private String cropName,cropTips,postDate,tipsId;

    public Database_CropTips(){}

    public Database_CropTips(String CropName, String CropTips, String PostDate, String TipsId){
        cropName=CropName;
        cropTips=CropTips;
        postDate=PostDate;
        tipsId=TipsId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getCropTips() {
        return cropTips;
    }

    public void setCropTips(String cropTips) {
        this.cropTips = cropTips;
    }

    public String getPostDate() {
        return postDate;
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public String getTipsId() {
        return tipsId;
    }

    public void setTipsId(String tipsId) {
        this.tipsId = tipsId;
    }
}