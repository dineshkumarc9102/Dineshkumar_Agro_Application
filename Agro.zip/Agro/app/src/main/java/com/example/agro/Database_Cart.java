package com.example.agro;

public class Database_Cart {
    private String imageAdress, pname, pprice, pdescription, pseller, sellerid, pquantity, pstock, pquantity2,imageId, qua_req, typeof, upTime, cartid,uid;

    public Database_Cart(){}

    public Database_Cart(String P_name,String P_price,String P_quantity,String P_description,String P_seller,String P_sellerid,String P_typeof,String P_stock,String P_quantity2,String Qua_req,String P_uptime,String imageUrl,String ImageId,String CartId,String Uid) {
        pname=P_name;
        pprice=P_price;
        pdescription=P_description;
        pseller=P_seller;
        sellerid=P_sellerid;
        typeof=P_typeof;
        pquantity=P_quantity;
        pstock=P_stock;
        pquantity2=P_quantity2;
        imageAdress=imageUrl;
        imageId=ImageId;
        qua_req=Qua_req;
        upTime=P_uptime;
        cartid=CartId;
        uid=Uid;
    }

    public String getImageAdress() {
        return imageAdress;
    }

    public void setImageAdress(String imageUrl) {
        imageAdress = imageUrl;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String P_name) {
        pname = P_name;
    }

    public String getPprice() {
        return pprice;
    }

    public void setPprice(String P_price) {
        pprice = P_price;
    }

    public String getPquantity() {return pquantity;}

    public void setPquantity(String P_quantity) {
        pquantity = P_quantity;
    }

    public String getPdescription() {
        return pdescription;
    }

    public void setPdescription(String P_description) {
        pdescription = P_description;
    }

    public String getPseller() {
        return pseller;
    }

    public void setPseller(String P_seller) {
        pseller = P_seller;
    }

    public String getSellerid() {
        return sellerid;
    }

    public void setSellerid(String P_sellerid) {
        sellerid = P_sellerid;
    }

    public String getTypeof() {return typeof;}

    public void setTypeof(String P_typeof) { typeof = P_typeof;}

    public String getPstock() {return pstock;}

    public void setPstock(String P_stock) { pstock = P_stock;}

    public String getPquantity2() {return pquantity2;}

    public void setPquantity2(String P_quantity2) {pquantity2 = P_quantity2; }

    public String getQua_req() {return qua_req;}

    public void setQua_req(String Qua_req) {qua_req = Qua_req; }

    public String getUpTime() {return upTime;}

    public void setUpTime(String P_uptime) {upTime = P_uptime; }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String ImageId) {
        imageId = ImageId;
    }

    public String getCartid() { return cartid; }

    public void setCartid(String CartId) { cartid = CartId; }

    public String getUid() {
        return uid;
    }

    public void setUid(String Uid) {
        uid = Uid;
    }

}
