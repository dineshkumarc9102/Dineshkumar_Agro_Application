package com.example.agro;

public class Database_Farmer_Schedule {

    private String date, work, uid;

    public Database_Farmer_Schedule(){}

    public Database_Farmer_Schedule(String Date,String Work,String Uid)
    {
        date=Date;
        work=Work;
        uid=Uid;
    }
    public String getDate() {
        return date;
    }

    public void setDate(String Date) { date = Date; }

    public String getWork() { return work; }

    public void setWork(String Work) { work = Work; }

    public String getUid() {
        return uid;
    }

    public void setUid(String Uid) {
        uid = Uid;
    }
}
