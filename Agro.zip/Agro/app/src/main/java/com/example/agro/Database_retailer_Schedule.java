package com.example.agro;

public class Database_retailer_Schedule {

    private String uname;
    private String rsname;
    private String rsprice;
    private String rsseller;
    private String rssellerid;
    private String rsqua_req;
    private String rsquantity;
    private String typeof;
    private String rsimageId;
    private String rsimage_address;
    private String sub_sun;
    private String sub_mon;
    private String sub_tue;
    private String sub_wed;
    private String sub_thu;
    private String sub_fri;
    private String sub_sat;
    private String uid;

    public Database_retailer_Schedule(){}

    public Database_retailer_Schedule(String Uname, String RS_name, String RS_price, String RSQua_req, String RS_quantity, String TypeOf, String RS_seller, String RS_sellerid, String Sun, String Mon, String Tue, String Wed, String Thu, String Fri, String Sat, String RSImageId, String RS_imageAddress, String Uid) {
        uname=Uname;
        rsname=RS_name;
        rsprice=RS_price;
        rsseller=RS_seller;
        rssellerid=RS_sellerid;
        rsquantity=RS_quantity;
        rsimageId=RSImageId;
        rsqua_req=RSQua_req;
        typeof=TypeOf;
        rsimage_address=RS_imageAddress;
        sub_sun=Sun;
        sub_mon=Mon;
        sub_tue=Tue;
        sub_wed=Wed;
        sub_thu=Thu;
        sub_fri=Fri;
        sub_sat=Sat;
        uid=Uid;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getRsname() {
        return rsname;
    }

    public void setRsname(String RS_name) {
        rsname = RS_name;
    }

    public String getRsprice() {
        return rsprice;
    }

    public void setRsprice(String RS_price) {
        rsprice = RS_price;
    }

    public String getRsquantity() {return rsquantity;}

    public void setRsquantity(String RS_quantity) {
        rsquantity = RS_quantity;
    }

    public String getTypeof() {
        return typeof;
    }

    public void setTypeof(String TypeOf) {
        typeof = TypeOf;
    }

    public String getRsseller() {
        return rsseller;
    }

    public void setRsseller(String RS_seller) {
        rsseller = RS_seller;
    }

    public String getRssellerid() {
        return rssellerid;
    }

    public void setRssellerid(String RS_sellerid) {
        rssellerid = RS_sellerid;
    }

    public String getRsqua_req() {return rsqua_req;}

    public void setRsqua_req(String RSQua_req) {rsqua_req = RSQua_req; }

    public String getSub_Sun(){return sub_sun; }

    public void setSub_Sun(String Sub_Sun){sub_sun=Sub_Sun; }

    public String getSub_Mon(){return sub_mon; }

    public void setSub_Mon(String Sub_Mon){sub_mon=Sub_Mon; }

    public String getSub_Tue(){return sub_tue; }

    public void setSub_Tue(String Sub_Tue){sub_tue=Sub_Tue; }

    public String getSub_Wed(){return sub_wed; }

    public void setSub_Wed(String Sub_Wed){sub_wed=Sub_Wed; }

    public String getSub_Thu(){return sub_thu; }

    public void setSub_Thu(String Sub_Thu){sub_thu=Sub_Thu; }

    public String getSub_Fri(){return sub_fri; }

    public void setSub_Fri(String Sub_Fri){sub_fri=Sub_Fri; }

    public String getSub_Sat() {
        return sub_sat;
    }

    public void setSub_Sat(String Sub_Sat) {
        sub_sat = Sub_Sat;
    }

    public String getRsimageId() {return rsimageId; }

    public void setRsimageId(String RSImageId) { rsimageId = RSImageId; }

    public String getRsimage_address() {return rsimage_address; }

    public void setRsimage_address(String RS_imageAddress) { rsimage_address = RS_imageAddress; }

    public String getUid() {
        return uid;
    }

    public void setUid(String Uid) {
        uid = Uid;
    }

}
