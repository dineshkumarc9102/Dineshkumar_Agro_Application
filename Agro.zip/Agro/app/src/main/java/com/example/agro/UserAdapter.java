package com.example.agro;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.MyViewHolder> implements Filterable {

    Context context;
    List<Database_products> database_products;
    List<Database_products> database_products_full;

    public UserAdapter(Context c,List<Database_products> p)
    {
        context=c;
        database_products=p;
        database_products_full=new ArrayList<>(p);
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v =LayoutInflater.from(context).inflate(R.layout.cardview,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final Database_products pr=database_products.get(position);
        holder.name.setText(database_products.get(position).getPname());
        holder.price.setText("₹" + database_products.get(position).getPprice());
        holder.quantity.setText(database_products.get(position).getPquantity());
        Picasso.get()
                .load(pr.getImageAdress())
                .resize(150,150)
                .centerCrop()
                .into(holder.gUserProduct);

        holder.Product.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent productpage=new Intent(context,Product_page.class);
                productpage.putExtra("imageAddress",pr.getImageId());
                productpage.putExtra("typeOf",pr.getTypeof());
                context.startActivity(productpage);
            }
        });
    }

    @Override
    public int getItemCount() {
        return database_products.size();
    }

    @Override
    public Filter getFilter() {
        return exampleFilter;
    }

    private Filter exampleFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<Database_products> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(database_products_full);
            }
            else
            {
                String filePattern =constraint.toString().toLowerCase().trim();
                for (Database_products item: database_products_full){
                    if(item.getPname().toLowerCase().contains(filePattern)){
                        filteredList.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filteredList;

            return  results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            database_products.clear();
            database_products.addAll((List) results.values);
            notifyDataSetChanged();

        }
    };

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        public TextView name,price,quantity;
        public ImageView gUserProduct;
        public LinearLayout Product;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=(TextView)itemView.findViewById(R.id.pName);
            price=(TextView)itemView.findViewById(R.id.pPrice);
            quantity=(TextView)itemView.findViewById(R.id.pQuantity);
            gUserProduct=(ImageView)itemView.findViewById(R.id.gUserProduct);
            Product=(LinearLayout)itemView.findViewById(R.id.product);
        }
    }
}