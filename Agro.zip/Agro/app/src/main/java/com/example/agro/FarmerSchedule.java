package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class FarmerSchedule extends AppCompatActivity {
    CalendarView calendarView;
    TextView Sdate;
    EditText Swork;
    String date,Work,S_work,T_date,currentDate,i;
    Database_Farmer_Schedule database_farmer_schedule;
    DatabaseReference reference;
    FirebaseUser user;
    FirebaseAuth lAuth;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.farmer_schedule);

        Sdate=(TextView)findViewById(R.id.date);
        Swork=(EditText)findViewById(R.id.work);
        progressBar=(ProgressBar)findViewById(R.id.progressBarSch);

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();

        database_farmer_schedule=new Database_Farmer_Schedule();
        reference= FirebaseDatabase.getInstance().getReference().child("Farmer_Schedule");

        Intent cal=getIntent();
        i=cal.getStringExtra("s");
        if (i.equals("home")) {
            String pattern = "dd:M:yyyy";
            currentDate = new SimpleDateFormat(pattern).format(new Date());
            Sdate.setText(currentDate);
            T_date = Sdate.getText().toString();
            Retrieve_sche(T_date);
        }
        else if (i.equals("allSche")){
            T_date= cal.getStringExtra("Date");
            Retrieve_sche(T_date);
        }

        calendarView = (CalendarView) findViewById(R.id.calendar);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
            progressBar.setVisibility(View.VISIBLE);
            String d = dayOfMonth + "";
            if (d.length() == 1) {
                date = "0" + dayOfMonth + ":" + (month + 1) + ":" + year;
                Sdate.setText(date);
            }
            else {
                date = dayOfMonth + ":" + (month + 1) + ":" + year;
                Sdate.setText(date);
            }
                T_date = Sdate.getText().toString();
                Retrieve_sche(T_date);
            }
        });
    }
    public void Add_Schedule(View view)
    {
        progressBar.setVisibility(View.VISIBLE);

        T_date = Sdate.getText().toString();
        Work=Swork.getText().toString().trim();

        if (Work.equals("")){
            Swork.setError("Enter Something");
            progressBar.setVisibility(View.GONE);
        }
        else if (T_date.equals("")){
            Sdate.setError("No date Selected");
            progressBar.setVisibility(View.GONE);
        }
        else {
            String UID=user.getUid();
            database_farmer_schedule = new Database_Farmer_Schedule(T_date, Work,UID);
            reference.child(user.getUid()).child(T_date).setValue(database_farmer_schedule).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(getApplicationContext(), "Added", Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE);

                    } else {
                        Toast.makeText(getApplicationContext(), "Can't add Error=" + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        progressBar.setVisibility(View.GONE);
                    }
                }
            });
        }
    }
    public void Retrieve_sche(String scheDate){
        final String S_date=scheDate;
        reference.child(user.getUid()).child(S_date).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    date = dataSnapshot.child("date").getValue().toString();
                    S_work = dataSnapshot.child("work").getValue().toString();
                    progressBar.setVisibility(View.GONE);
                }
                else
                {
                    date=S_date;
                    S_work="";
                    progressBar.setVisibility(View.GONE);
                }

                Sdate.setText(date);
                Swork.setText(S_work);
                Swork.setSelection(Swork.getText().length());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(FarmerSchedule.this,"Data not fetched.....",Toast.LENGTH_LONG);
                progressBar.setVisibility(View.GONE);

            }
        });

    }
}
