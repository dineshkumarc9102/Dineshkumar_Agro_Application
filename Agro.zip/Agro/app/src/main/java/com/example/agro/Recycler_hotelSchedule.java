package com.example.agro;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Recycler_hotelSchedule extends RecyclerView.Adapter<Recycler_hotelSchedule.ScheduleHolder> {

    Context context;
    List<Database_retailer_Schedule> hotel_schedules;
    DatabaseReference ref_user;
    FirebaseAuth lAuth;
    FirebaseUser user;
    String category;

    public Recycler_hotelSchedule(Context c,List<Database_retailer_Schedule> r){
        context=c;
        hotel_schedules=r;
    }

    @NonNull
    @Override
    public ScheduleHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.cardview_hotel_schedule,parent,false);
        return new Recycler_hotelSchedule.ScheduleHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final ScheduleHolder holder, final int position) {
        final Database_retailer_Schedule rs=hotel_schedules.get(position);
        holder.hs_name.setText(hotel_schedules.get(position).getRsname());
        holder.hs_req.setText(hotel_schedules.get(position).getRsqua_req());
        holder.hs_qua.setText(hotel_schedules.get(position).getRsquantity());
        String sun = "",mon = "",tue = "",wed = "",thu = "",fri = "",sat = "";
        if (hotel_schedules.get(position).getSub_Sun().equals("Yes")) sun="| Sun |";
        if (hotel_schedules.get(position).getSub_Mon().equals("Yes")) mon="| Mon |";
        if (hotel_schedules.get(position).getSub_Tue().equals("Yes")) tue="| Tue |";
        if (hotel_schedules.get(position).getSub_Wed().equals("Yes")) wed="| Wed |";
        if (hotel_schedules.get(position).getSub_Thu().equals("Yes")) thu="| Thu |";
        if (hotel_schedules.get(position).getSub_Fri().equals("Yes")) fri="| Fri |";
        if (hotel_schedules.get(position).getSub_Sat().equals("Yes")) sat="| Sat |";

        holder.sub.setText("Subscription = "+sun+mon+tue+wed+thu+fri+sat);

        Picasso.get()
                .load(rs.getRsimage_address())
                .resize(150,150)
                .centerCrop()
                .into(holder.hs_image);

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();
        ref_user= FirebaseDatabase.getInstance().getReference().child("User");
        ref_user.child(user.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    category=dataSnapshot.child("category").getValue().toString();

                    if (category.equals("Farmer")){
                        holder.sellerName.setText("Subscriber : "+hotel_schedules.get(position).getUname());
                        holder.hs_edit.setVisibility(View.GONE);
                    }
                    else if (category.equals("Retailer/Hotels")){
                        holder.sellerName.setText("Seller : "+hotel_schedules.get(position).getRsseller());
                        holder.hs_Product.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent productpage=new Intent(context,Product_page.class);
                                productpage.putExtra("imageAddress",rs.getRsimageId());
                                productpage.putExtra("typeOf",rs.getTypeof());
                                context.startActivity(productpage);
                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    @Override
    public int getItemCount() {
        return hotel_schedules.size();
    }

    public class ScheduleHolder extends RecyclerView.ViewHolder {
        public TextView hs_name,hs_req,hs_qua,sub,sellerName;
        public ImageView hs_image,hs_edit;
        public LinearLayout hs_Product;
        public ScheduleHolder(@NonNull View itemView) {
            super(itemView);
            hs_name=(TextView)itemView.findViewById(R.id.HsName);
            hs_req=(TextView)itemView.findViewById(R.id.Hs_req);
            hs_qua=(TextView)itemView.findViewById(R.id.HsQuantity);
            sellerName=(TextView)itemView.findViewById(R.id.HssellerName);
            sub=(TextView)itemView.findViewById(R.id.HsSubscription);
            hs_image=(ImageView)itemView.findViewById(R.id.hs_image);
            hs_edit=(ImageView)itemView.findViewById(R.id.edit_subscribe);
            hs_Product=(LinearLayout)itemView.findViewById(R.id.hs_product);
        }
    }
}