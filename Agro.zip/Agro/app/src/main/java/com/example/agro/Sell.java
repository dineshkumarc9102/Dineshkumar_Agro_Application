package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Sell extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int CAMERA_REQUEST=1888;
    private  static final int MY_CAMERA_PERMISSION_CODE=100;
    private Button choose,camera;
    private Button upload;
    private EditText name,price,description,quantity,stock,quantity2;
    private ImageView imageView;
    private ProgressBar progressBar;
    Spinner spinner;
    String currentPhotoPath;
    private Uri mImageUri,contentUri;
    StorageReference mStorageRef;
    TextView seller;
    Database_products database_products;
    DatabaseReference reff;
    String typeof,url;
    FirebaseUser user;
    String myname,uploadPass,imageId;
    FirebaseAuth lAuth;
    DatabaseReference reference;
    int flag=0;

    String P_name,P_price,P_quantity,P_description,P_seller,P_sellerid,P_stock,P_quantity2,Uptime,P_permission="pending";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);

        choose = (Button)findViewById(R.id.gallery);
        camera=(Button)findViewById(R.id.camera);
        upload = (Button)findViewById(R.id.upload);
        name=(EditText)findViewById(R.id.p_name);
        price=(EditText)findViewById(R.id.p_price);
        quantity=(EditText)findViewById(R.id.p_quantity);
        description=(EditText)findViewById(R.id.p_description);
        stock=(EditText)findViewById(R.id.p_stock);
        quantity2=(EditText)findViewById(R.id.p_quantity2);
        imageView=(ImageView)findViewById(R.id.photo);
        progressBar=(ProgressBar)findViewById(R.id.progressBar_load);
        seller=(TextView)findViewById(R.id.seller);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy  'at' hh:mm a");
        Uptime = sdf.format(new Date());

        lAuth = FirebaseAuth.getInstance();
        reference= FirebaseDatabase.getInstance().getReference().child("User");

        user=lAuth.getCurrentUser();  //Getting user name to set seller name

        P_sellerid=user.getUid();
        reference.child(user.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                myname = dataSnapshot.child("name").getValue().toString();
                seller.setText(myname);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Sell.this,"Something Went Wrong......Can,t get Name",Toast.LENGTH_SHORT).show();
            }
        });

        spinner=(Spinner)findViewById(R.id.spinner);   //setting spinner

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.type_of_product,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        mStorageRef= FirebaseStorage.getInstance().getReference("Product_Farmers");//storing image in storage

        database_products=new Database_products();
        reff= FirebaseDatabase.getInstance().getReference().child("Product_farmers");


        choose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag=1;
                openFileChooser();
            }
        });

        camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                flag=2;
               askCameraPermissions();
            }
        });

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                P_name = name.getText().toString().trim().toUpperCase();
                P_price = price.getText().toString().trim();
                P_quantity = quantity.getText().toString().trim();
                P_description = description.getText().toString().trim();
                P_seller = seller.getText().toString().trim();
                P_stock=stock.getText().toString().trim();
                P_quantity2=quantity2.getText().toString().trim();

                if (flag == 0){
                    Toast.makeText(Sell.this,"No Image Found",Toast.LENGTH_SHORT).show();
                    progressBar.setVisibility(View.GONE);
                }
                else if (P_name.equals("")) {
                    name.setError("Enter Product name");
                    return;
                }
                else if (P_price.equals("")) {
                    price.setError("Enter price");
                    return;
                }
                else if (P_quantity.equals("")) {
                    quantity.setError("Enter quantity");
                    return;
                }
                else if (P_stock.equals("")) {
                    stock.setError("Enter stock You Have");
                    return;
                }
                else if (P_quantity2.equals("")) {
                    quantity2.setError("Enter quantity eg.Kg");
                    return;
                }
                else if (typeof.equals("Choose type of product")) {
                    Toast.makeText(Sell.this,"Select type of product",Toast.LENGTH_LONG).show();
                }
                else if (P_description.equals("")) {
                    description.setError("Enter about the product");
                    return;
                }
                else
                {
                    progressBar.setVisibility(View.VISIBLE);

                    if (flag == 1)
                    {
                        Fileuploader();
                    }
                    else if (flag == 2)
                    {
                        uploadImageToFirebase(uploadPass, contentUri);
                    }
                }
            }
        });
    }

    private void askCameraPermissions(){
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},MY_CAMERA_PERMISSION_CODE);
        }else {
            dispatchTakePictureIntent();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==MY_CAMERA_PERMISSION_CODE)
        {
            dispatchTakePictureIntent();
        }
        else
        {
            Toast.makeText(this,"Camera Permission is Required to Use camera.",Toast.LENGTH_SHORT).show();
        }
    }

    private String getExtension(Uri uri)
    {
        ContentResolver cr=getContentResolver();
        MimeTypeMap mimeTypeMap=MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));
    }

    public void Fileuploader()
    {
            final StorageReference Ref=mStorageRef.child(typeof).child(System.currentTimeMillis()+"."+getExtension(mImageUri));
            imageId=System.currentTimeMillis()+"";
            if(mImageUri != null) {
                Ref.putFile(mImageUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                Toast.makeText(Sell.this, "The product is under verification", Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);

                                Ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        url = uri.toString();
                                        Database_products product = new Database_products(P_name, P_price, P_quantity, P_description, P_seller,P_sellerid, typeof,P_stock,P_quantity2,Uptime, url,imageId,P_permission);
                                        reff.child(typeof).child(imageId).setValue(product);
                                    }
                                });
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(Sell.this, "Can't upload the image", Toast.LENGTH_LONG).show();
                            }
                        });
            }
            else {
                Toast.makeText(Sell.this,"Image not selected",Toast.LENGTH_SHORT).show();
            }
    }

    public void openFileChooser(){
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null)
        {
            mImageUri = data.getData();
            Picasso.get().load(mImageUri).into(imageView);
        }

        if(requestCode==CAMERA_REQUEST) {
            if (resultCode == Activity.RESULT_OK) {

            File f = new File(currentPhotoPath);
            imageView.setImageURI(Uri.fromFile(f));
            Log.d("tag","Absolute Url of page is "+Uri.fromFile(f));

            Intent mediaScanIntent=new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            contentUri = Uri.fromFile(f);
            mediaScanIntent.setData(contentUri);
            this.sendBroadcast(mediaScanIntent);
            uploadPass=f.getName();
            }
        }
    }

    private void uploadImageToFirebase(String cname,Uri contentUri)
    {
            final StorageReference Ref = mStorageRef.child(typeof).child("Pictures/"+cname);
            imageId=System.currentTimeMillis()+"";
            if (contentUri != null) {
                Ref.putFile(contentUri)
                        .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                Toast.makeText(Sell.this, "The product is under verification", Toast.LENGTH_LONG).show();
                                progressBar.setVisibility(View.GONE);

                                Ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                    @Override
                                    public void onSuccess(Uri uri) {
                                        url = uri.toString();
                                        Database_products product = new Database_products(P_name, P_price, P_quantity, P_description, P_seller,P_sellerid, typeof,P_stock,P_quantity2,Uptime, url,imageId,P_permission);
                                        reff.child(typeof).child(imageId).setValue(product);
                                    }
                                });
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception exception) {
                                // Handle unsuccessful uploads
                                progressBar.setVisibility(View.GONE);
                                Toast.makeText(Sell.this, "Can't upload the image", Toast.LENGTH_LONG).show();
                            }
                        });
            } else {
                Toast.makeText(Sell.this, "Image not selected", Toast.LENGTH_SHORT).show();
            }
    }

    private void dispatchTakePictureIntent(){
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(takePictureIntent.resolveActivity(getPackageManager()) != null){
            File photoFile = null;
            try {
                photoFile = createImageFile();

            }catch (IOException ex){}

            if(photoFile != null)
            {
                Uri photoURI = FileProvider.getUriForFile(this,"com.example.android.provider",photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT,photoURI);
                startActivityForResult(takePictureIntent,CAMERA_REQUEST);
            }
        }
    }

    private File createImageFile() throws IOException{
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_"+timeStamp+"_";
        File storageDir=getApplicationContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,".jpg",storageDir
        );

        currentPhotoPath=image.getAbsolutePath();
        return image;
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        typeof=parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {}
}