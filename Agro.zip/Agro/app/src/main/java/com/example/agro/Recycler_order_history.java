package com.example.agro;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class Recycler_order_history extends RecyclerView.Adapter<Recycler_order_history.MyViewHolder> {

    Context context;
    List<Database_Order_history> order_histories;

    public Recycler_order_history(Context c,List<Database_Order_history> oh)
    {
        context=c;
        order_histories=oh;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.cardview_order_history,parent,false);
        return new Recycler_order_history.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final Database_Order_history orderHistory=order_histories.get(position);
         {
            holder.ohName.setText(order_histories.get(position).getPname());
            holder.ohQue.setText("Purchased "+order_histories.get(position).getQua_req());
            holder.ohKg.setText(order_histories.get(position).getPquantity());
            holder.ohTotal.setText("₹ "+order_histories.get(position).getPtotal());
            holder.ohDetails.setText("Ordered on "+order_histories.get(position).getOrderdate()+", Sold by "+order_histories.get(position).getPseller());
            Picasso.get()
                    .load(orderHistory.getImageAdress())
                    .resize(200, 200)
                    .centerCrop()
                    .into(holder.ohProduct);
        }
    }

    @Override
    public int getItemCount() {
        return order_histories.size();
    }

    public class
    MyViewHolder extends RecyclerView.ViewHolder {

        public TextView ohName,ohQue,ohKg,ohTotal,ohDetails;
        public ImageView ohProduct;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ohName=(TextView)itemView.findViewById(R.id.oh_pName);
            ohQue=(TextView)itemView.findViewById(R.id.oh_ordered_qua);
            ohKg=(TextView)itemView.findViewById(R.id.oh_inkg);
            ohDetails=(TextView)itemView.findViewById(R.id.oh_details);
            ohTotal=(TextView)itemView.findViewById(R.id.oh_total);
            ohProduct=(ImageView)itemView.findViewById(R.id.Product_oh);
        }
    }
}
