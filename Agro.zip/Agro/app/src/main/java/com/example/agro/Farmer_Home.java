package com.example.agro;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
public class Farmer_Home extends Fragment {

    ImageView Seeds,Fertilizer,Pesticide;
    Button AddSchedule,ViewSchedule;
    TextView Schedule,Tdate;
    DatabaseReference reference;
    FirebaseUser user;
    FirebaseAuth lAuth;
    String SDate,SWork;
    ProgressBar process;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View farmer_homefrag = inflater.inflate(R.layout.farmer__home, container, false);

        Schedule=(TextView)farmer_homefrag.findViewById(R.id.schedule);
        Tdate=(TextView)farmer_homefrag.findViewById(R.id.today_date);
        AddSchedule=(Button)farmer_homefrag.findViewById(R.id.add_schedule);
        ViewSchedule=(Button)farmer_homefrag.findViewById(R.id.view_schedule);
        Seeds=(ImageView) farmer_homefrag.findViewById(R.id.seeds);
        Fertilizer=(ImageView) farmer_homefrag.findViewById(R.id.fertilizer);
        Pesticide=(ImageView) farmer_homefrag.findViewById(R.id.pesticide);
        reference= FirebaseDatabase.getInstance().getReference("Farmer_Schedule");
        process=(ProgressBar)farmer_homefrag.findViewById(R.id.progressBar5);

        String pattern = "dd:M:yyyy";
        final String currentDateTime = new SimpleDateFormat(pattern).format(new Date());

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();

         reference.child(user.getUid()).child(currentDateTime).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    SDate = dataSnapshot.child("date").getValue().toString();
                    SWork = dataSnapshot.child("work").getValue().toString();
                    process.setVisibility(View.GONE);
                }
                else {
                    SDate="*"+currentDateTime+"*";
                    SWork="No Schedule Today";
                    process.setVisibility(View.GONE);
                }

                //progressBar.setVisibility(View.GONE);

                Tdate.setText(SDate);
                Schedule.setText(SWork);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getActivity(),"Data not fetched.....",Toast.LENGTH_LONG);
                process.setVisibility(View.GONE);

            }
        });

        AddSchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addsche=new Intent(getActivity(),FarmerSchedule.class);
                addsche.putExtra("s","home");
                startActivity(addsche);
            }
        });

        ViewSchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent viewsche=new Intent(getActivity(),Farmer_allschedule.class);
                startActivity(viewsche);
            }
        });

        Seeds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(),ProductList.class);
                i.putExtra("Category","Seeds");
                startActivity(i);
            }
        });

        Fertilizer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(),ProductList.class);
                i.putExtra("Category","Fertilizers");
                startActivity(i);
            }
        });

        Pesticide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getActivity(),ProductList.class);
                i.putExtra("Category","Pesticide");
                startActivity(i);
            }
        });

        return farmer_homefrag;
    }
}
