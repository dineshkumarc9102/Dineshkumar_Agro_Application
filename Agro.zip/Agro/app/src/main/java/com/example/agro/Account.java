package com.example.agro;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Account extends AppCompatActivity {

    TextView name,mobile,emailid,typeof;
    String U_name,U_emailid,U_mobile,U_typeOf;
    ImageView prImage,Update;
    ProgressBar progressBar;
    User user;
    FirebaseAuth lAuth;
    DatabaseReference reference;
    Button button_Address,Logout;
    ProgressBar progressAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

        name=(TextView) findViewById(R.id.User_name);
        emailid=(TextView)findViewById(R.id.User_emailid);
        mobile=(TextView) findViewById(R.id.User_mobile);
        typeof=(TextView)findViewById(R.id.User_type);
        Update=(ImageView) findViewById(R.id.update);
        button_Address=(Button)findViewById(R.id.address_page);
        Logout=(Button)findViewById(R.id.account_logout);
        progressAccount=(ProgressBar)findViewById(R.id.progressBar_account);

        lAuth = FirebaseAuth.getInstance();

        reference= FirebaseDatabase.getInstance().getReference().child("User");
        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    U_name = dataSnapshot.child("name").getValue().toString();
                    U_emailid = dataSnapshot.child("email").getValue().toString();
                    U_mobile = dataSnapshot.child("mobileno").getValue().toString();
                    U_typeOf = dataSnapshot.child("category").getValue().toString();
                }
                /*Picasso.get()
                        .load(pImage)
                        .resize(1000,1000)
                        .centerCrop()
                        .into(prImage);

                progressBar.setVisibility(View.GONE);*/

                name.setText(U_name);
                emailid.setText(U_emailid);
                mobile.setText(U_mobile);
                typeof.setText(U_typeOf);

                progressAccount.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Account.this,"Data not fetched.....",Toast.LENGTH_LONG).show();

            }
        });

        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent update=new Intent(Account.this,Account_Update.class);
                startActivity(update);
            }
        });

        button_Address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent address=new Intent(Account.this,UserAddress.class);
                startActivity(address);
            }
        });

        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder logout=new AlertDialog.Builder(Account.this);
                logout.setTitle("Logout")
                        .setMessage("Do you want to Logout")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                Account.super.onBackPressed();
                                finish();
                            }
                        })
                        .setNegativeButton("No",null).show();
            }
        });

    }
}
