package com.example.agro;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Recycler_orders extends RecyclerView.Adapter<Recycler_orders.MyViewHolder> {

   Context context;
   List<Database_orders> orders;

   public Recycler_orders(Context c,List<Database_orders> o)
   {
       context=c;
       orders=o;
   }

    @NonNull
    @Override
    public Recycler_orders.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View v = LayoutInflater.from(context).inflate(R.layout.cardview_orders,parent,false);
       return new Recycler_orders.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Recycler_orders.MyViewHolder holder, int position) {
        final Database_orders or=orders.get(position);
        holder.orName.setText(orders.get(position).getOname());
        holder.orQuantity.setText(orders.get(position).getOquantity());
        holder.orQuantityReq.setText(orders.get(position).getOqua_req());
        holder.orAddress.setText(orders.get(position).getAddress());
        Picasso.get()
                .load(or.getOimage_address())
                .resize(200,200)
                .centerCrop()
                .into(holder.orImage);

    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        public TextView orName,orQuantityReq,orQuantity,orAddress;
        public ImageView orImage;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            orName=(TextView)itemView.findViewById(R.id.order_pName);
            orQuantityReq=(TextView)itemView.findViewById(R.id.order_quantityreq);
            orQuantity=(TextView)itemView.findViewById(R.id.order_kg);
            orAddress=(TextView)itemView.findViewById(R.id.order_address);
            orImage=(ImageView)itemView.findViewById(R.id.OrderProduct);
        }
    }
}
