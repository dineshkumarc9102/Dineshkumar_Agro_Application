package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

public class Login extends AppCompatActivity {

    EditText email,password;
    FirebaseAuth lAuth;
    ProgressBar progressBar;
    TextView ForgetPassword;
    FirebaseUser fUser;
    String Password,Email;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email=(EditText)findViewById(R.id.username);
        password=(EditText)findViewById(R.id.password);

        lAuth = FirebaseAuth.getInstance();
        fUser=lAuth.getInstance().getCurrentUser();
        user=lAuth.getCurrentUser();

        progressBar=(ProgressBar)findViewById(R.id.progressBar);

        ForgetPassword=(TextView) findViewById(R.id.resetPassword);
        ForgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final EditText resetMail = new EditText(v.getContext());
                resetMail.setBackgroundColor(Color.parseColor("#DFD5D5"));
                resetMail.setPadding(30,10,30,10);
                resetMail.setTextSize(20);
                resetMail.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
                AlertDialog.Builder passwordReset=new AlertDialog.Builder(v.getContext());
                passwordReset.setTitle("Reset Password");
                passwordReset.setMessage("Enter the Mail Id To Receive Reset Link");
                passwordReset.setView(resetMail);
                passwordReset.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        String Mail=resetMail.getText().toString();
                        if (!Mail.isEmpty()){
                            lAuth.sendPasswordResetEmail(Mail).addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(getApplicationContext(), "Link Send To Your Mail Id", Toast.LENGTH_SHORT).show();
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(getApplicationContext(), "Link Not Send:" + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                        else {
                            Toast.makeText(Login.this,"Please enter your Email Id",Toast.LENGTH_SHORT).show();
                        }
                    }
                }).setNegativeButton("No",null).show();
            }
        });
    }

    public void signup(View view)
    {
        Intent i=new Intent(Login.this,SignUp.class);
        startActivity(i);
    }

    public void login(View view)
    {
        Email = email.getText().toString();
        Password = password.getText().toString();

        if (Email.equals(""))
        {
            email.setError("Enter Email ID");
            return;
        }
        else if (Password.equals(""))
        {
            password.setError("Enter Password");
            return;
        }
        else if (Password.length()<6)
        {
            password.setError("Password must be atleast 6 characters");
            return;
        }
        else {
            progressBar.setVisibility(View.VISIBLE);

            lAuth.signInWithEmailAndPassword(Email,Password).addOnCompleteListener(this,new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful())
                    {
                        if (lAuth.getCurrentUser().isEmailVerified())
                        {
                            Intent getmap=new Intent(getApplicationContext(),GetMap.class);
                            getmap.putExtra("NewPassword",Password);
                            startActivity(getmap);
                            finish();
                            progressBar.setVisibility(View.GONE);
                        }
                        else
                        {
                            Toast.makeText(Login.this,"Please verify your Email Id",Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                    else {
                        Toast.makeText(Login.this,"Error="+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        progressBar.setVisibility(View.GONE);
                    }
                }
            });
        }
    }

    @Override
    public void onBackPressed()
    {
        Login.super.onBackPressed();
    }
}
