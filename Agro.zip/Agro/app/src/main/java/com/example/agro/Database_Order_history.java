package com.example.agro;

public class Database_Order_history {

    private String imageAdress, pname, pprice, ptotal, orderdate, pseller, sellerid, pquantity, pstock, pquantity2, imageId, qua_req,uid;


    public Database_Order_history(){}

    public Database_Order_history(String P_name,String P_price,String P_Total,String P_quantity,String P_orderdate,String P_seller,String P_sellerid,String P_stock,String P_quantity2,String Qua_req,String imageUrl,String ImageId,String Uid) {
        pname=P_name;
        pprice=P_price;
        ptotal=P_Total;
        orderdate=P_orderdate;
        pseller=P_seller;
        sellerid=P_sellerid;
        pquantity=P_quantity;
        pstock=P_stock;
        pquantity2=P_quantity2;
        imageAdress=imageUrl;
        imageId=ImageId;
        qua_req=Qua_req;
        uid=Uid;
    }

    public String getImageAdress() {
        return imageAdress;
    }

    public void setImageAdress(String imageUrl) {
        imageAdress = imageUrl;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String P_name) {
        pname = P_name;
    }

    public String getPprice() {
        return pprice;
    }

    public void setPprice(String P_price) {
        pprice = P_price;
    }

    public String getPtotal() {
        return ptotal;
    }

    public void setPtotal(String P_Total) {
        ptotal = P_Total;
    }

    public String getPquantity() {return pquantity;}

    public void setPquantity(String P_quantity) {
        pquantity = P_quantity;
    }

    public String getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(String P_orderdate) { orderdate = P_orderdate; }

    public String getPseller() {
        return pseller;
    }

    public void setPseller(String P_seller) {
        pseller = P_seller;
    }

    public String getSellerid() {
        return sellerid;
    }

    public void setSellerid(String P_sellerid) {
        sellerid = P_sellerid;
    }

    public String getPstock() {return pstock;}

    public void setPstock(String P_stock) { pstock = P_stock;}

    public String getPquantity2() {return pquantity2;}

    public void setPquantity2(String P_quantity2) {pquantity2 = P_quantity2; }

    public String getQua_req() {return qua_req;}

    public void setQua_req(String Qua_req) {qua_req = Qua_req; }

    public String getImageId() {
        return imageId;
    }

    public void setImageId(String ImageId) {
        imageId = ImageId;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String Uid) {
        uid = Uid;
    }

}
