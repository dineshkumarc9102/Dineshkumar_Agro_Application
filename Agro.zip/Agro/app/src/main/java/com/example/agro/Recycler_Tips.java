package com.example.agro;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Recycler_Tips extends RecyclerView.Adapter<Recycler_Tips.MyViewHolder> {

    Context context;
    List<Database_CropTips> cropTips;

    public Recycler_Tips(Context c,List<Database_CropTips> ct)
    {
        context=c;
        cropTips=ct;
    }

    @NonNull
    @Override
    public Recycler_Tips.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.cardview_tips,parent,false);
        return new Recycler_Tips.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Recycler_Tips.MyViewHolder holder, int position) {
        holder.TipsDate.setText(cropTips.get(position).getPostDate());
        holder.Crop_Name.setText(cropTips.get(position).getCropName()+" :");
        holder.Crop_Tips.setText(cropTips.get(position).getCropTips());
    }

    @Override
    public int getItemCount() {
        return cropTips.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView TipsDate,Crop_Name,Crop_Tips;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            TipsDate=(TextView)itemView.findViewById(R.id.tips_date);
            Crop_Name=(TextView)itemView.findViewById(R.id.crop_name);
            Crop_Tips=(TextView)itemView.findViewById(R.id.crop_tips);
        }
    }
}
