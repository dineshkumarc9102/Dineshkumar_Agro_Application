package com.example.agro;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.provider.ContactsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Recycler_post extends RecyclerView.Adapter<Recycler_post.MyViewHolder>  {

    Context context;
    List<Database_products> products;
    DatabaseReference reference;
    FirebaseAuth lAuth;

    public Recycler_post(Context c,List<Database_products> p)
    {
        context=c;
        products=p;
    }

    @NonNull
    @Override
    public Recycler_post.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.cardview_post,parent,false);
        return new Recycler_post.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Recycler_post.MyViewHolder holder, final int position) {
        final Database_products pr=products.get(position);
        holder.name.setText(products.get(position).getPname());
        holder.price.setText("₹" + products.get(position).getPprice());
        holder.quantity.setText(products.get(position).getPquantity());
        holder.permission.setText(products.get(position).getpPermission());
        if (products.get(position).getpPermission().equals("approved")){
            holder.permission.setTextColor(Color.parseColor("green"));
        }
        else if (products.get(position).getpPermission().equals("pending")){
            holder.permission.setTextColor(Color.parseColor("#FFDD00"));
        }
        else if (products.get(position).getpPermission().equals("rejected")){
            holder.permission.setTextColor(Color.parseColor("red"));
        }
        Picasso.get()
                .load(pr.getImageAdress())
                .resize(150,150)
                .centerCrop()
                .into(holder.ProductImage);

        holder.Delete_myPost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder Del_post=new AlertDialog.Builder(context);
                Del_post.setTitle("Alert")
                        .setMessage("Do You want to delete this post")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                lAuth = FirebaseAuth.getInstance();
                                reference=FirebaseDatabase.getInstance().getReference().child("Product_farmers");
                                reference.child(products.get(position).getTypeof()).child(products.get(position).getImageId()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(context, "Product Deleted Successfully", Toast.LENGTH_SHORT).show();
                                            notifyDataSetChanged();
                                        }
                                        else
                                        {
                                            Toast.makeText(context,"Database Error="+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                        }
                                    }
                                });

                            }
                        })
                        .setNegativeButton("No",null).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView name,price,quantity,permission;
        public ImageView ProductImage,Delete_myPost;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=(TextView)itemView.findViewById(R.id.post_pName);
            price=(TextView)itemView.findViewById(R.id.post_pPrice);
            quantity=(TextView)itemView.findViewById(R.id.post_pQuantity);
            permission=(TextView)itemView.findViewById(R.id.post_permission);
            ProductImage=(ImageView)itemView.findViewById(R.id.post_UserProduct);
            Delete_myPost=(ImageView)itemView.findViewById(R.id.delete_mypost);
        }
    }
}
