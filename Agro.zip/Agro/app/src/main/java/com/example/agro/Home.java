package com.example.agro;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.firebase.database.DatabaseReference;

public class Home extends Fragment {
    ImageView Fruits,Vegetables,Millet,Greens,MilkProducts,Spices;
    String category;

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View homefrag=inflater.inflate(R.layout.activity_home,container,false);

        Fruits=(ImageView)homefrag.findViewById(R.id.fruits);
        Vegetables=(ImageView) homefrag.findViewById(R.id.vegetables);
        Millet=(ImageView) homefrag.findViewById(R.id.millet);
        Greens=(ImageView) homefrag.findViewById(R.id.greens);
        MilkProducts=(ImageView) homefrag.findViewById(R.id.milk_products);
        Spices=(ImageView)homefrag.findViewById(R.id.spices);


        Fruits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Fruits";
                gotoProductList(category);
            }
        });

        Vegetables.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Vegetables";
                gotoProductList(category);
            }
        });

        Millet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Millet";
                gotoProductList(category);
            }
        });

        Greens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Greens";
                gotoProductList(category);
            }
        });

        MilkProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Milk Products";
                gotoProductList(category);
            }
        });

        Spices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Spices";
                gotoProductList(category);
            }
        });

        return homefrag;
    }
    private void gotoProductList(String category) {
        Intent i=new Intent(getActivity(),ProductList.class);
        i.putExtra("Category",category);
        startActivity(i);
    }
}