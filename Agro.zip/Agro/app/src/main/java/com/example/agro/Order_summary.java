package com.example.agro;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Order_summary extends AppCompatActivity {

    String Total,house_no,area,city,state,landmark,pincode,View_Address,buyname;
    TextView Amount,Address;
    DatabaseReference reference,reffcart,refforders,ref_order_history,reff_product,ref_address;
    FirebaseAuth lAuth;
    FirebaseUser user;
    String pname, pprice, Qua_req, pquantity, pseller, psellerid, stock, productId,pdescription,pquantity2,pImage,typeOf,NewStock,orderid;
    Button Order;
    String flag,uptime,OrderOn;
    LinearLayout PaymentLayout,OrderSummaryLayout;
    ProgressBar progressBar_orderSummary;
    String UID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_summary);

        PaymentLayout=(LinearLayout)findViewById(R.id.payment_layout);
        OrderSummaryLayout=(LinearLayout)findViewById(R.id.orderSummary_layout);
        progressBar_orderSummary=(ProgressBar)findViewById(R.id.progressBar_summary);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                PaymentLayout.setVisibility(View.GONE);
                OrderSummaryLayout.setVisibility(View.VISIBLE);
            }
        },3000);

        Amount=(TextView)findViewById(R.id.confirm_total);
        Address=(TextView)findViewById(R.id.confirm_address);
        Order=(Button)findViewById(R.id.order);

        Intent t=getIntent();
        Total=t.getStringExtra("Total");
        flag=t.getStringExtra("purchase_flag");
        Amount.setText("₹"+Total);

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();
        UID=user.getUid();

        reference= FirebaseDatabase.getInstance().getReference().child("User");
        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    buyname=dataSnapshot.child("name").getValue().toString();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Order_summary.this,"Data not fetched.....",Toast.LENGTH_LONG).show();
                progressBar_orderSummary.setVisibility(View.GONE);
            }
        });

        ref_address= FirebaseDatabase.getInstance().getReference().child("Address");
        ref_address.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    house_no=dataSnapshot.child("").child("houseno").getValue().toString();
                    area=dataSnapshot.child("area").getValue().toString();
                    city=dataSnapshot.child("city").getValue().toString();
                    state=dataSnapshot.child("state").getValue().toString();
                    landmark=dataSnapshot.child("landmark").getValue().toString();
                    pincode=dataSnapshot.child("pincode").getValue().toString();
                }
                View_Address=buyname+",\n"+house_no+" ,"+area+",\n"+city+", "+state+", "+landmark+"  -"+pincode+".";
                Address.setText(View_Address);
                progressBar_orderSummary.setVisibility(View.GONE);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Order_summary.this,"Data not fetched.....",Toast.LENGTH_LONG).show();
                progressBar_orderSummary.setVisibility(View.GONE);
            }
        });

        user=lAuth.getCurrentUser();
        reffcart= FirebaseDatabase.getInstance().getReference("Cart");
        refforders=FirebaseDatabase.getInstance().getReference().child("Orders");
        ref_order_history=FirebaseDatabase.getInstance().getReference().child("Order History");
        reff_product=FirebaseDatabase.getInstance().getReference().child("Product_farmers");

        Order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar_orderSummary.setVisibility(View.VISIBLE);
                if (flag.equals("single")){
                    Intent i=getIntent();
                    pname = i.getStringExtra("pname");
                    pprice = i.getStringExtra("pprice");
                    Qua_req = i.getStringExtra("Qua_req");
                    pquantity = i.getStringExtra("pquantity");
                    pseller = i.getStringExtra("pseller");
                    psellerid = i.getStringExtra("psellerid");
                    productId = i.getStringExtra("productId");
                    pdescription = i.getStringExtra("pdescription");
                    pquantity2 = i.getStringExtra("pquantity2");
                    pImage = i.getStringExtra("pImage");
                    typeOf=i.getStringExtra("pTypeof");
                    NewStock=i.getStringExtra("NewStock");
                    uptime=i.getStringExtra("UpTime");

                    String P_permission="approved";

                    Database_products product = new Database_products(pname, pprice, pquantity, pdescription, pseller,psellerid, typeOf,NewStock,pquantity2,uptime, pImage,productId,P_permission);
                    reff_product.child(typeOf).child(productId).setValue(product).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                progressBar_orderSummary.setVisibility(View.GONE);
                            }
                            else {
                                Toast.makeText(Order_summary.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                progressBar_orderSummary.setVisibility(View.GONE);
                            }
                        }
                    });

                    Upload_Database(pname, pprice,Total, Qua_req, pquantity, pseller, psellerid, stock, productId,pquantity2,pImage,typeOf,NewStock);
                }
            //cart
                if (flag.equals("cart")){
                    reffcart.child(UID).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()) {
                                for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                                    Database_Cart d = dataSnapshot1.getValue(Database_Cart.class);
                                    pname = d.getPname();
                                    pprice = d.getPprice();
                                    Qua_req = d.getQua_req();
                                    pquantity = d.getPquantity();
                                    pseller = d.getPseller();
                                    psellerid = d.getSellerid();
                                    productId = d.getImageId();
                                    pquantity2 = d.getPquantity2();
                                    pImage = d.getImageAdress();
                                    typeOf=d.getTypeof();

                                    Upload_Database(pname, pprice,Total, Qua_req, pquantity, pseller, psellerid, stock, productId,pquantity2,pImage,typeOf,NewStock);

                                    reffcart.child(UID).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()){ }
                                            else {
                                                Toast.makeText(Order_summary.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });

                                    progressBar_orderSummary.setVisibility(View.GONE);
                                }
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(Order_summary.this, "Ooops... Something is wrong...", Toast.LENGTH_SHORT).show();
                            progressBar_orderSummary.setVisibility(View.GONE);
                        }
                    });
                }
            }
        });
    }
    public void Upload_Database(String Pname, String Pprice,String Ptotal,String PQua_req,String Pquantity, String Pseller, String Psellerid,String Pstock,String PproductId,String Pquantity2, String PImage,String PtypeOf,String PNewStock){
        pname=Pname;
        pprice=Pprice;
        Total=Ptotal;
        Qua_req=PQua_req;
        pquantity=Pquantity;
        pseller=Pseller;
        psellerid=Psellerid;
        stock=Pstock;
        productId=PproductId;
        pquantity2=Pquantity2;
        pImage=PImage;
        typeOf=PtypeOf;
        NewStock=PNewStock;

        orderid=System.currentTimeMillis()+""+productId;

        Database_orders database_orders = new Database_orders(pname, pprice,Total, Qua_req, pquantity, pseller, psellerid, productId, View_Address,pImage,UID);
        refforders.child(psellerid).child(orderid).setValue(database_orders).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {
                    TextView orderPlaced=new TextView(getApplicationContext());
                    orderPlaced.setText("Your Order Placed successfully\nContinue Shopping");
                    orderPlaced.setTextSize(26);
                    orderPlaced.setPadding(20,10,20,10);
                    orderPlaced.setGravity(Gravity.CENTER);
                    orderPlaced.setTextColor(Color.parseColor("green"));
                    AlertDialog.Builder confirm=new AlertDialog.Builder(Order_summary.this);
                    confirm.setView(orderPlaced)
                            .show();
                }
                else {
                    Toast.makeText(Order_summary.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy 'at' hh:mm a");
        OrderOn= sdf.format(new Date());

        Database_Order_history database_order_history = new Database_Order_history(pname, pprice,Total, pquantity, OrderOn, pseller, psellerid, stock, pquantity2, Qua_req, pImage, productId,UID);
        ref_order_history.child(UID).child(orderid).setValue(database_order_history).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) { }
                else {
                    Toast.makeText(Order_summary.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
