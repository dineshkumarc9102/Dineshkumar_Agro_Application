package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Post_ProductList extends AppCompatActivity {

    DatabaseReference reference;
    RecyclerView recyclerView;
    List<Database_products> list;
    Recycler_post adapter_post;
    String category;
    FirebaseAuth lAuth;
    ImageView No_Post;
    ProgressBar progressBar_Post;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.post_product_list);

        lAuth = FirebaseAuth.getInstance();

        No_Post=(ImageView)findViewById(R.id.no_post);
        progressBar_Post=(ProgressBar)findViewById(R.id.progressBar_PostProductList);

        recyclerView = (RecyclerView)findViewById(R.id.UserRecycler_post);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();

        Intent i=getIntent();
        category=i.getStringExtra("Post_Category");

        reference= FirebaseDatabase.getInstance().getReference("Product_farmers");
        reference.child(category).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    list = new ArrayList<>();
                    list.clear();
                    adapter_post = new Recycler_post(Post_ProductList.this, list);
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        Database_products p = dataSnapshot1.getValue(Database_products.class);
                        if (p.getSellerid().equals(lAuth.getUid())) {
                            list.add(p);
                            No_Post.setVisibility(View.INVISIBLE);
                            progressBar_Post.setVisibility(View.GONE);
                        }
                    }
                    adapter_post = new Recycler_post(Post_ProductList.this, list);
                    recyclerView.setAdapter(adapter_post);
                }
                else {
                    No_Post.setVisibility(View.VISIBLE);
                    progressBar_Post.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Post_ProductList.this,"Ooops... Something is wrong...",Toast.LENGTH_SHORT).show();
                progressBar_Post.setVisibility(View.GONE);
            }
        });
    }
}
