package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Account_Update extends AppCompatActivity {

    DatabaseReference reference,update_ref;
    EditText name,mobile;
    TextView emailid,typeof;
    String U_Id,U_name,U_Password,U_emailid,U_mobile,U_typeOf,U_id,New_name,New_mobile;
    ImageView prImage,Edit_image,Edit_name,Edit_mobile;
    ProgressBar progressBar;
    FirebaseAuth lAuth;
    Button Delete,Update;
    ProgressBar progressAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account__update);

        name=(EditText)findViewById(R.id.Update_name);
        emailid=(TextView)findViewById(R.id.Update_emailid);
        mobile=(EditText)findViewById(R.id.Update_mobile);
        typeof=(TextView)findViewById(R.id.Update_type);
        Delete=(Button)findViewById(R.id.delete_account);
        Edit_name=(ImageView)findViewById(R.id.edit_name);
        Edit_mobile=(ImageView)findViewById(R.id.edit_mobile);
        Update=(Button)findViewById(R.id.update_data);
        progressAccount=(ProgressBar)findViewById(R.id.progressBar_account);

        Edit_name.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name.setEnabled(true);
                name.setSelection(name.getText().length());

                Update.setEnabled(true);
                Update.setVisibility(View.VISIBLE);
            }
        });

        Edit_mobile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mobile.setEnabled(true);
                mobile.setSelection(mobile.getText().length());

                Update.setEnabled(true);
                Update.setVisibility(View.VISIBLE);
            }
        });

        lAuth = FirebaseAuth.getInstance();

        reference= FirebaseDatabase.getInstance().getReference().child("User");
        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    U_Id=dataSnapshot.child("uid").getValue().toString();
                    U_name = dataSnapshot.child("name").getValue().toString();
                    U_Password=dataSnapshot.child("password").getValue().toString();
                    U_emailid = dataSnapshot.child("email").getValue().toString();
                    U_mobile = dataSnapshot.child("mobileno").getValue().toString();
                    U_typeOf = dataSnapshot.child("category").getValue().toString();
                }
                /*Picasso.get()
                        .load(pImage)
                        .resize(1000,1000)
                        .centerCrop()
                        .into(prImage);

                progressBar.setVisibility(View.GONE);*/

                name.setText(U_name);
                emailid.setText(U_emailid);
                mobile.setText(U_mobile);
                typeof.setText(U_typeOf);

                progressAccount.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Account_Update.this,"Data not fetched.....",Toast.LENGTH_LONG).show();

            }
        });

        Update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressAccount.setVisibility(View.VISIBLE);
                New_name=name.getText().toString();
                New_mobile=mobile.getText().toString();
                update_ref= FirebaseDatabase.getInstance().getReference().child("User");
                User UpdateUser = new User(New_name,U_Password,New_mobile,U_emailid,U_typeOf,U_Id);
                update_ref.child(lAuth.getUid()).setValue(UpdateUser).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(Account_Update.this,"Updated Successfully",Toast.LENGTH_SHORT).show();
                            name.setEnabled(false);
                            Update.setEnabled(false);
                            Update.setVisibility(View.INVISIBLE);
                            progressAccount.setVisibility(View.GONE);
                            Intent back=new Intent(Account_Update.this,Account.class);
                            startActivity(back);
                            finish();
                        }
                        else {
                            Toast.makeText(Account_Update.this,"Error="+task.getException().getMessage(),Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });

        Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final FirebaseUser luser = FirebaseAuth.getInstance().getCurrentUser();

                U_id=lAuth.getUid();
                AlertDialog.Builder dialog = new AlertDialog.Builder(Account_Update.this);
                dialog.setTitle("Alert")
                        .setMessage("Do you want to Delete Your Account")
                        .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                luser.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task)
                                    {
                                        if (task.isSuccessful())
                                        {
                                            FirebaseAuth.getInstance().signOut();
                                            Intent i=new Intent(Account_Update.this,Login.class);
                                            startActivity(i);
                                            Account_Update.this.finish();
                                            Toast.makeText(Account_Update.this,"Account Deleted Successfully",Toast.LENGTH_SHORT).show();

                                    /* refDelete= FirebaseDatabase.getInstance().getReference().child("User");
                                     refDelete.child(U_id).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                         @Override
                                         public void onComplete(@NonNull Task<Void> task) {
                                             if (task.isSuccessful())
                                             {
                                                 Toast.makeText(Account.this,"Account Deleted Successfully",Toast.LENGTH_SHORT).show();

                                             }
                                             else
                                             {
                                                 Toast.makeText(Account.this,"Database Error="+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                             }
                                         }
                                     });*/
                                        }
                                        else
                                        {
                                            Toast.makeText(Account_Update.this,"Auth Error="+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                        }
                                    }
                                });
                            }
                        })
                        .setNegativeButton("NO", null).show();
            }
        });
    }
}
