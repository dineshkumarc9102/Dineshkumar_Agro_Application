package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Cart extends AppCompatActivity {

    DatabaseReference reference,address_ref;
    RecyclerView recyclerView;
    List<Database_Cart> list;
    Recycler_cart adapter_cart;
    FirebaseUser user;
    FirebaseAuth lAuth;
    TextView amount;
    Button Place_order;
    String price,quantity,Tot_amount;
    Double total,rate,sum,qua,discount;
    ImageView EmptyCart;
    ProgressBar progressBar_cart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        EmptyCart=(ImageView)findViewById(R.id.empty_cart);
        progressBar_cart=(ProgressBar)findViewById(R.id.progressBar_cart);

        recyclerView = (RecyclerView)findViewById(R.id.UserRecycler_cart);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();
        amount=(TextView)findViewById(R.id.total_amount);
        Place_order=(Button)findViewById(R.id.place_order);

        reference= FirebaseDatabase.getInstance().getReference("Cart");
        reference.child(user.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    EmptyCart.setVisibility(View.INVISIBLE);
                    progressBar_cart.setVisibility(View.GONE);
                    list = new ArrayList<>();
                    list.clear();
                    adapter_cart = new Recycler_cart(Cart.this, list);
                    total=0.0;
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        Database_Cart d = dataSnapshot1.getValue(Database_Cart.class);
                        list.add(d);
                        adapter_cart.notifyDataSetChanged();

                        price = d.getPprice();
                        quantity = d.getQua_req();
                        rate = Double.parseDouble(price);
                        qua = Double.parseDouble(quantity);
                        sum = rate * qua;

                        if (qua > 10) {
                            discount = sum * 0.10;
                            sum = sum - discount;
                        }
                        else if (qua > 50) {
                            discount = sum * 0.15;
                            sum = sum - discount;
                        }
                        total = total + sum;
                    }
                    adapter_cart = new Recycler_cart(Cart.this, list);
                    recyclerView.setAdapter(adapter_cart);
                    amount.setText("Total: ₹" + total);
                }
                else {
                    list.clear();
                    EmptyCart.setVisibility(View.VISIBLE);
                    progressBar_cart.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Cart.this,"Ooops... Something is wrong...",Toast.LENGTH_SHORT).show();
                progressBar_cart.setVisibility(View.GONE);
            }
        });

        Place_order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                address_ref = FirebaseDatabase.getInstance().getReference().child("Address");
                address_ref.child(user.getUid()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.child("houseno").exists()){
                            Tot_amount=total+"";
                            Intent placeorder=new Intent(Cart.this,Order_summary.class);
                            placeorder.putExtra("Total",Tot_amount);
                            placeorder.putExtra("purchase_flag","cart");
                            startActivity(placeorder);
                        }
                        else {
                            Intent address = new Intent(Cart.this, UserAddress.class);
                            startActivity(address);
                            finish();
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(Cart.this,"Ooops... Something is wrong...",Toast.LENGTH_SHORT).show();
                        progressBar_cart.setVisibility(View.GONE);
                    }
                });
            }
        });
    }
}
