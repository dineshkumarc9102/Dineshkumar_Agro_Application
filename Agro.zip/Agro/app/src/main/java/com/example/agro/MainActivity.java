package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private static int SPLASH_TIME_OUT = 2000;
    FirebaseAuth mAuth,reauth;
    DatabaseReference reference;
    String category,email,password;
    FirebaseUser fUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().hide();

        fUser=FirebaseAuth.getInstance().getCurrentUser();
        mAuth = FirebaseAuth.getInstance();
        reference= FirebaseDatabase.getInstance().getReference().child("User");

        reauth=FirebaseAuth.getInstance();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isConnected()) {
                    AlertDialog.Builder back = new AlertDialog.Builder(MainActivity.this);
                    back.setTitle("NO Internet Alert")
                            .setMessage("Please check your internet connection")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            })
                            .show();
                }
                else
                    {
                    if (mAuth.getCurrentUser() != null && mAuth.getCurrentUser().isEmailVerified()) {

                        reference.child(mAuth.getUid()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if (dataSnapshot.exists()) {

                                    if (dataSnapshot.child("category").exists()) {
                                        category = dataSnapshot.child("category").getValue().toString();
                                    } else {
                                        LoginPage();
                                    }

                                    if (dataSnapshot.child("email").exists()) {
                                        email = dataSnapshot.child("email").getValue().toString();
                                    } else {
                                        LoginPage();
                                    }

                                    if (dataSnapshot.child("password").exists()) {
                                        password = dataSnapshot.child("password").getValue().toString();
                                    } else {
                                        LoginPage();
                                    }

                                    AuthCredential credential = EmailAuthProvider.getCredential(email, password);
                                    fUser.reauthenticate(credential)
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if (task.isSuccessful()) {

                                                        if (category.equals("Farmer")) {
                                                            Intent i = new Intent(MainActivity.this, Mainpage.class);
                                                            startActivity(i);
                                                            finish();
                                                        } else if (category.equals("General User")) {
                                                            Intent i = new Intent(MainActivity.this, GeneralUser_main.class);
                                                            startActivity(i);
                                                            finish();
                                                        } else if (category.equals("Retailer/Hotels")) {
                                                            Intent i = new Intent(MainActivity.this, Retailer_main.class);
                                                            startActivity(i);
                                                            finish();
                                                        }
                                                    } else {
                                                        Toast.makeText(MainActivity.this, "Error=" + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                                    }
                                                }
                                            });
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                                Toast.makeText(MainActivity.this, "Something Went Wrong......", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                    else {
                        LoginPage();
                    }
                }
            }
        },SPLASH_TIME_OUT);
    }
    public void LoginPage(){
        Intent intent = new Intent(MainActivity.this, Login.class);
        startActivity(intent);
        finish();
    }
    public boolean isConnected()
    {
        ConnectivityManager connectivityManager=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=connectivityManager.getActiveNetworkInfo();
        return networkInfo !=null && networkInfo.isConnected();
    }
}