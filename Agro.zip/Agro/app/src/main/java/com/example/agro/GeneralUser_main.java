package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class GeneralUser_main extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout g_drawerLayout;
    ActionBarDrawerToggle g_actionBarDrawerToggle;
    Toolbar g_toolbar;
    NavigationView g_navigationView;
    FragmentManager g_fragmentManager;
    FragmentTransaction g_fragmentTransaction;
    FirebaseAuth lAuth;
    DatabaseReference reference;
    String U_name;
    TextView UserName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.general_user_main);

        g_toolbar=findViewById(R.id.toolbar_generaluser);
        setSupportActionBar(g_toolbar);
        g_drawerLayout=findViewById(R.id.drawer_generaluser);
        g_navigationView=findViewById(R.id.navigationView_generaluser);
        g_navigationView.setNavigationItemSelectedListener(this);

        View uView= g_navigationView.getHeaderView(0);
        UserName=(TextView)uView.findViewById(R.id.myname);

        lAuth = FirebaseAuth.getInstance();
        reference= FirebaseDatabase.getInstance().getReference().child("User");
        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("name").exists()) {
                    U_name = dataSnapshot.child("name").getValue().toString();
                    UserName.setText(U_name);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"Data not fetched.....",Toast.LENGTH_LONG).show();
            }
        });

        g_actionBarDrawerToggle=new ActionBarDrawerToggle(this,g_drawerLayout,g_toolbar,R.string.open,R.string.close);
        g_drawerLayout.addDrawerListener(g_actionBarDrawerToggle);
        g_actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        g_actionBarDrawerToggle.syncState();

        //load default fragment

        g_fragmentManager = getSupportFragmentManager();
        g_fragmentTransaction=g_fragmentManager.beginTransaction();
        g_fragmentTransaction.add(R.id.fragment_container_generaluser,new Home());
        g_fragmentTransaction.commit();
    }
    public boolean loadFrag(Fragment fragment){
        if (fragment != null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container_generaluser,fragment).
                    commit();
            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        g_drawerLayout.closeDrawer(GravityCompat.START);
        Fragment fragment=null;
        switch (menuItem.getItemId()){
            case R.id.g_home:
                fragment = new Home();
                break;

            case R.id.g_cart:
                Intent c=new Intent(GeneralUser_main.this,Cart.class);
                startActivity(c);
                break;

            case R.id.g_myaccount:
                Intent g_acc=new Intent(GeneralUser_main.this,Account.class);
                startActivity(g_acc);
                break;

            case R.id.g_orderhistory:
                Intent orderhistory =new Intent(GeneralUser_main.this,Order_history.class);
                startActivity(orderhistory);
                break;

            case R.id.g_logout:
                AlertDialog.Builder logout=new AlertDialog.Builder(GeneralUser_main.this);
                logout.setTitle("Logout")
                        .setMessage("Do you want to Logout")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                GeneralUser_main.super.onBackPressed();
                                finish();
                            }
                        })
                        .setNegativeButton("No",null).show();
                break;
        }
        return loadFrag(fragment);
    }

    @Override
    public void onBackPressed()
    {
        AlertDialog.Builder back = new AlertDialog.Builder(GeneralUser_main.this);
        back.setTitle("Alert")
                .setMessage("Do you want to Exit")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        GeneralUser_main.super.onBackPressed();
                    }
                })
                .setNegativeButton("No",null).show();
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.product_menu,menu);

        MenuItem cart = menu.findItem(R.id.add_to_cart);

        MenuItem searchItem =menu.findItem(R.id.action_search);
        searchItem.setVisible(false);

        cart.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent c =new Intent(getApplicationContext(),Cart.class);
                startActivity(c);
                return false;
            }
        });
        return true;
    }

}
