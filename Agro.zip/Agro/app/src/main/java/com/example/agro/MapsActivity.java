package com.example.agro;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback, LocationListener {

    private GoogleMap mMap;
    LocationManager locationManager;
    final static int PERMISSION_ALL = 1;
    final static String[] PERMISSIONS = {android.Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION};
    MarkerOptions markerOptions;
    Marker marker;
    FloatingActionButton Re_locate;
    ProgressBar progressBarMap;
    TextView Address_Map;
    LatLng myCoordinates;
    Geocoder geocoder;
    String address=null,houseno=null ,city=null, state=null, country=null, pincode=null, knownName=null,landmark=null,Latitude, Longitude;
    Double latitude, longitude;
    Button Save_map;
    DatabaseReference reference;
    FirebaseUser user;
    FirebaseAuth lAuth;
    String category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
        Re_locate=(FloatingActionButton)findViewById(R.id.re_locate);
        progressBarMap=(ProgressBar)findViewById(R.id.progressBarMap);
        Address_Map=(TextView)findViewById(R.id.address_map);
        Save_map=(Button)findViewById(R.id.save_mapAddress);

        lAuth= FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference().child("Address");

        LoadMap();

        Re_locate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBarMap.setVisibility(View.VISIBLE);
                Save_map.setVisibility(View.GONE);
                LoadMap();
            }
        });
        final String UID=user.getUid();
        Save_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Database_Address address = new Database_Address(houseno, knownName, city, state, landmark, pincode,Latitude,Longitude,UID);
                reference.child(UID).setValue(address).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Address Saves Successfully.......", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Address Not Saved ..." + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
                Intent back=new Intent(getApplicationContext(),GetMap.class);
                startActivity(back);
                finish();
            }
        });
    }

    public void LoadMap(){
        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        markerOptions = new MarkerOptions().position(new LatLng(0, 0));
        if (Build.VERSION.SDK_INT >= 23 && !isPermissionGranted()) {
            requestPermissions(PERMISSIONS, PERMISSION_ALL);
        } else requestLocation();
        if (!isLocationEnabled())
            showAlert(1);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        marker = mMap.addMarker(markerOptions);
    }

    @Override
    public void onLocationChanged(Location location) {
        myCoordinates = new LatLng(location.getLatitude(), location.getLongitude());
        marker.setPosition(myCoordinates);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(myCoordinates));
        progressBarMap.setVisibility(View.GONE);
        Save_map.setVisibility(View.VISIBLE);

        latitude=myCoordinates.latitude;
        longitude=myCoordinates.longitude;
        List<android.location.Address> addresses;
        geocoder=new Geocoder(this, Locale.getDefault());

        try {
            addresses=geocoder.getFromLocation(latitude,longitude,1);

            address=addresses.get(0).getAddressLine(0);
            city=addresses.get(0).getLocality();
            state=addresses.get(0).getAdminArea();
            country=addresses.get(0).getCountryName();
            pincode=addresses.get(0).getPostalCode();
            knownName=addresses.get(0).getFeatureName();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Latitude=latitude+"";
        Longitude=longitude+"";

        markerOptions = new MarkerOptions().position(new LatLng(latitude, longitude)).title(latitude+" "+longitude);
        marker = mMap.addMarker(markerOptions);
        marker.setPosition(myCoordinates);
        Address_Map.setText(address);
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    public void requestLocation() {
        Criteria criteria = new Criteria();
        criteria.setAccuracy(Criteria.ACCURACY_FINE);
        criteria.setPowerRequirement(Criteria.POWER_MEDIUM);
        String provider = locationManager.getBestProvider(criteria, true);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        locationManager.requestLocationUpdates(provider, 1000, 10, this);
    }
    public boolean isLocationEnabled(){
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }
    @RequiresApi(api = Build.VERSION_CODES.M)
    public boolean isPermissionGranted(){
        if (checkSelfPermission(android.Manifest.permission.ACCESS_COARSE_LOCATION)
                == PackageManager.PERMISSION_GRANTED || checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),"Loading Your Location",Toast.LENGTH_SHORT).show();
            return true;
        }
        else {
            Toast.makeText(getApplicationContext(),"Permission Denied",Toast.LENGTH_SHORT).show();
            return false;
        }

    }
    private void showAlert(final int i) {
        String message,title,btnText;
        if (i==1){
            message="Your Location Settings is set to off\nPlease Enable Location to use this app";
            title="Enable Location";
            btnText="Location Settings";
        }
        else {
            message="Please allow this app to access location";
            title="Permission access";
            btnText="Grant";
        }
        AlertDialog.Builder loc=new AlertDialog.Builder(this);
        loc.setCancelable(false);
        loc.setTitle(title)
                .setMessage(message)
                .setPositiveButton(btnText, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (i==1){
                            Intent myMapIntent=new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                            startActivity(myMapIntent);
                        }
                        else {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                requestPermissions(PERMISSIONS,PERMISSION_ALL);
                            }
                        }
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }).show();
    }

}