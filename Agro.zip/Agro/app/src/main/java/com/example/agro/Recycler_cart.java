package com.example.agro;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Recycler_cart extends RecyclerView.Adapter<Recycler_cart.MyViewHolder> {

    Context context;
    List<Database_Cart> database_cart;
    DatabaseReference reff,reff_product;
    FirebaseAuth lAuth;

    public Recycler_cart(Context c,List<Database_Cart> d)
    {
        context=c;
        database_cart=d;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.cardview_cart,parent,false);
        return new Recycler_cart.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final Recycler_cart.MyViewHolder holder, final int position) {
        final Database_Cart ca=database_cart.get(position);
        holder.name.setText(database_cart.get(position).getPname());
        holder.price.setText("₹" + database_cart.get(position).getPprice());
        holder.quantity.setText(database_cart.get(position).getPquantity());
        holder.stock_kg.setText(database_cart.get(position).getPquantity());
        holder.qua.setText(database_cart.get(position).getQua_req());
        Picasso.get()
                .load(ca.getImageAdress())
                .resize(200,200)
                .centerCrop()
                .into(holder.ProductImage);

        reff_product = FirebaseDatabase.getInstance().getReference().child("Product_farmers");
        reff_product.child(database_cart.get(position).getTypeof()).child(database_cart.get(position).getImageId()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final String pstock;
                if (dataSnapshot.exists()){
                    pstock = dataSnapshot.child("pstock").getValue().toString();
                }
                else {
                    pstock = "0";
                }
                holder.cstock.setText(pstock);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(context,"Database Error.....",Toast.LENGTH_LONG).show();
            }
        });

        holder.Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lAuth = FirebaseAuth.getInstance();
                reff= FirebaseDatabase.getInstance().getReference().child("Cart");
                AlertDialog.Builder del=new AlertDialog.Builder(context);
                del.setTitle("Alert")
                        .setMessage("Do you want to remove this product")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (database_cart.isEmpty()) {}
                                else {
                                    final int[] stock = new int[100];
                                    final int[] qua = new int[100];
                                    final int[] newStock = new int[100];
                                    String P_permission="approved";
                                    String GetStock=holder.cstock.getText().toString();
                                    stock[position] = Integer.parseInt(GetStock);
                                    qua[position] = Integer.parseInt(database_cart.get(position).getQua_req());
                                    newStock[position] = stock[position] + qua[position];
                                    String UpdateStock = newStock[position] + "";
                                    Database_products product = new Database_products(
                                            database_cart.get(position).getPname(),
                                            database_cart.get(position).getPprice(),
                                            database_cart.get(position).getPquantity(),
                                            database_cart.get(position).getPdescription(),
                                            database_cart.get(position).getPseller(),
                                            database_cart.get(position).getSellerid(),
                                            database_cart.get(position).getTypeof(),
                                            UpdateStock,
                                            database_cart.get(position).getPquantity2(),
                                            database_cart.get(position).getUpTime(),
                                            database_cart.get(position).getImageAdress(),
                                            database_cart.get(position).getImageId(),
                                            P_permission);

                                            reff_product.child(database_cart.get(position).getTypeof()).child(database_cart.get(position).getImageId()).setValue(product).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                reff.child(lAuth.getUid()).child(database_cart.get(position).getCartid()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                    @Override
                                                    public void onComplete(@NonNull Task<Void> task) {
                                                        if (task.isSuccessful()) {
                                                            Toast.makeText(context, "Product Deleted Successfully", Toast.LENGTH_SHORT).show();
                                                            notifyDataSetChanged();
                                                        }
                                                        else
                                                        {
                                                            Toast.makeText(context,"Database Error="+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                                        }
                                                    }
                                                });
                                            }
                                            else {
                                                Toast.makeText(context, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                }
                            }
                        })
                        .setNegativeButton("No",null).show();
            }
        });
    }

    @Override
    public int getItemCount() {return database_cart.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder
    {
        public TextView name,price,quantity,qua,cstock,stock_kg;
        public ImageView ProductImage,Delete;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=(TextView)itemView.findViewById(R.id.Name_cart);
            price=(TextView)itemView.findViewById(R.id.Price_cart);
            quantity=(TextView)itemView.findViewById(R.id.Quantity_cart);
            qua=(TextView) itemView.findViewById(R.id.Qua_cart);
            cstock=(TextView)itemView.findViewById(R.id.stock_cart);
            stock_kg=(TextView)itemView.findViewById(R.id.stock_kg_cart);
            ProductImage=(ImageView)itemView.findViewById(R.id.cart_image);
            Delete=(ImageView)itemView.findViewById(R.id.cart_delete);
        }
    }
}
