package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Order_history extends AppCompatActivity {

    DatabaseReference reference;
    RecyclerView recyclerView;
    List<Database_Order_history> list;
    Recycler_order_history recycler_order_history;
    FirebaseUser user;
    FirebaseAuth lAuth;
    ImageView NoOrders;
    ProgressBar progressBar_orderHis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        NoOrders=(ImageView)findViewById(R.id.noorder_history);
        progressBar_orderHis=(ProgressBar)findViewById(R.id.progressBar_orderHistory);

        recyclerView = (RecyclerView)findViewById(R.id.Recycler_order_history);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();

        reference= FirebaseDatabase.getInstance().getReference("Order History");
        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    NoOrders.setVisibility(View.INVISIBLE);
                    progressBar_orderHis.setVisibility(View.GONE);
                    list = new ArrayList<>();
                    list.clear();
                    recycler_order_history = new Recycler_order_history(Order_history.this, list);

                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        Database_Order_history d = dataSnapshot1.getValue(Database_Order_history.class);
                        list.add(d);
                        recycler_order_history.notifyDataSetChanged();
                    }
                    recycler_order_history = new Recycler_order_history(Order_history.this, list);
                    recyclerView.setAdapter(recycler_order_history);
                }
                else {
                    NoOrders.setVisibility(View.VISIBLE);
                    progressBar_orderHis.setVisibility(View.GONE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Order_history.this,"Ooops... Something is wrong...",Toast.LENGTH_SHORT).show();
                progressBar_orderHis.setVisibility(View.GONE);
            }
        });
    }
}
