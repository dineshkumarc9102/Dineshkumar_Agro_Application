package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ProgressBar;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ProductList extends AppCompatActivity {

    DatabaseReference reference;
    RecyclerView recyclerView;
    List<Database_products> list;
    UserAdapter adapter;
    String category;
    ProgressBar progressBar_productList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product__list);

        progressBar_productList=(ProgressBar)findViewById(R.id.progressBar_ProductList);

        recyclerView = (RecyclerView)findViewById(R.id.gUserRecyclera);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        list = new ArrayList<>();

        final Intent i=getIntent();
        category=i.getStringExtra("Category");

        reference= FirebaseDatabase.getInstance().getReference("Product_farmers");
        reference.child(category).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    progressBar_productList.setVisibility(View.GONE);
                    list = new ArrayList<>();
                    list.clear();
                    adapter = new UserAdapter(ProductList.this, list);
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        Database_products p = dataSnapshot1.getValue(Database_products.class);
                        if (p.getpPermission().equals("approved")) {
                            list.add(p);
                        }
                    }
                    adapter = new UserAdapter(ProductList.this, list);
                    recyclerView.setAdapter(adapter);
                }
                else {
                    progressBar_productList.setVisibility(View.GONE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ProductList.this,"Ooops... Something is wrong...",Toast.LENGTH_SHORT).show();
                progressBar_productList.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.product_menu,menu);

        MenuItem searchItem =menu.findItem(R.id.action_search);

        SearchView searchView=(SearchView)searchItem.getActionView();

        searchView.setImeOptions(EditorInfo.IME_ACTION_DONE);

        MenuItem cart = menu.findItem(R.id.add_to_cart);

        cart.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent c =new Intent(getApplicationContext(),Cart.class);
                startActivity(c);
                return false;
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        return true;
    }
}
