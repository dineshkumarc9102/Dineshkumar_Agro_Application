package com.example.agro;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class Recycler_Farm_AllSche extends RecyclerView.Adapter<Recycler_Farm_AllSche.MyViewHolder> {

    Context context;
    List<Database_Farmer_Schedule> farmer_schedules;
    DatabaseReference reff_schedule;
    FirebaseAuth lAuth;

    public Recycler_Farm_AllSche(Context c,List<Database_Farmer_Schedule> f){
        context=c;
        farmer_schedules=f;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.cardview_farmer_allschedule,parent,false);
        return new Recycler_Farm_AllSche.MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, final int position) {
        final Database_Farmer_Schedule dfs=farmer_schedules.get(position);
        holder.Fdate.setText(farmer_schedules.get(position).getDate());
        holder.Fwork.setText(farmer_schedules.get(position).getWork());

        holder.Farm_schedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent calender=new Intent(context,FarmerSchedule.class);
                calender.putExtra("Date",holder.Fdate.getText());
                calender.putExtra("s","allSche");
                context.startActivity(calender);
            }
        });

        holder.Delete_farmsche.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                lAuth = FirebaseAuth.getInstance();
                reff_schedule= FirebaseDatabase.getInstance().getReference().child("Farmer_Schedule");

                AlertDialog.Builder sche=new AlertDialog.Builder(context);
                sche.setTitle("Alert")
                        .setMessage("Do You Want To Delete Thr Schedule")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                reff_schedule.child(lAuth.getUid()).child(farmer_schedules.get(position).getDate()).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Toast.makeText(context, "Schedule Deleted Successfully", Toast.LENGTH_SHORT).show();
                                            notifyDataSetChanged();
                                        }
                                        else
                                        {
                                            Toast.makeText(context,"Database Error="+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                        }
                                    }
                                });

                            }
                        })
                        .setNegativeButton("No",null)
                        .show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return farmer_schedules.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView Fdate,Fwork;
        public ImageView Delete_farmsche;
        public LinearLayout Farm_schedule;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            Fdate=(TextView)itemView.findViewById(R.id.allsche_date);
            Fwork=(TextView)itemView.findViewById(R.id.allsche_work);
            Farm_schedule=(LinearLayout)itemView.findViewById(R.id.farm_sche);
            Delete_farmsche=(ImageView)itemView.findViewById(R.id.delete_farmsche);
        }
    }
}
