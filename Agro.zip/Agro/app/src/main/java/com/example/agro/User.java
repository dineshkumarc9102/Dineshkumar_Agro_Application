package com.example.agro;

public class User {
    private String name,password,mobileno,email,category,uid;

    public User() {
    }

    public User(String Name,String Password,String Mobileno,String Email,String Category,String Uid){
        name=Name;
        password=Password;
        mobileno=Mobileno;
        email=Email;
        category=Category;
        uid=Uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String Name) {
        name = Name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String Password) {
        password = Password;
    }

    public String getMobileno() {
        return mobileno;
    }

    public void setMobileno(String Mobileno) {
        mobileno = Mobileno;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String Email) {
        email = Email;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String Category) { category = Category; }

    public String getUid() {
        return uid;
    }

    public void setUid(String Uid) {
        uid = Uid;
    }

}
