package com.example.agro;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MyPost extends AppCompatActivity {

    Button Fruits,Vegetables,Millet,Greens,MilkProducts,Spices;
    String category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_post);

        Fruits=(Button)findViewById(R.id.post_fruits);
        Vegetables=(Button)findViewById(R.id.post_vegetables);
        Millet=(Button)findViewById(R.id.post_millet);
        Greens=(Button)findViewById(R.id.post_greens);
        MilkProducts=(Button)findViewById(R.id.post_milk_products);
        Spices=(Button)findViewById(R.id.post_spices);

        Fruits.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Fruits";
                gotoProductList(category);
            }
        });

        Vegetables.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Vegetables";
                gotoProductList(category);
            }
        });

        Millet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Millet";
                gotoProductList(category);
            }
        });

        Greens.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Greens";
                gotoProductList(category);
            }
        });

        MilkProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Milk Products";
                gotoProductList(category);
            }
        });

        Spices.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                category="Spices";
                gotoProductList(category);
            }
        });
    }

    private void gotoProductList(String Category) {
        Intent i=new Intent(getApplicationContext(),Post_ProductList.class);
        i.putExtra("Post_Category",Category);
        startActivity(i);
    }
}
