package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Hotel_sub_farm extends AppCompatActivity {

    DatabaseReference reference;
    RecyclerView recyclerView;
    List<Database_retailer_Schedule> retailer_scheduleList;
    Recycler_hotelSchedule recycler_hotelSchedule;
    FirebaseUser user;
    FirebaseAuth lAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hotel_sub_farm);

        recyclerView = (RecyclerView)findViewById(R.id.Recycler_hotelSch_farm);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        retailer_scheduleList = new ArrayList<>();

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();

        reference= FirebaseDatabase.getInstance().getReference("Subscribers_farmer");
        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    retailer_scheduleList = new ArrayList<>();
                    retailer_scheduleList.clear();
                    recycler_hotelSchedule = new Recycler_hotelSchedule(Hotel_sub_farm.this, retailer_scheduleList);

                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        Database_retailer_Schedule d = dataSnapshot1.getValue(Database_retailer_Schedule.class);
                        retailer_scheduleList.add(d);
                        recycler_hotelSchedule.notifyDataSetChanged();
                    }
                    recycler_hotelSchedule = new Recycler_hotelSchedule(Hotel_sub_farm.this, retailer_scheduleList);
                    recyclerView.setAdapter(recycler_hotelSchedule);
                }
                else {
                    Toast.makeText(getApplicationContext(),"nothing",Toast.LENGTH_SHORT).show();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"Ooops... Something is wrong...",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
