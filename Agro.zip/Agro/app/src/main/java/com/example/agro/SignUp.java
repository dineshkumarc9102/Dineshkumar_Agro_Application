package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Network;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {

    EditText name,password,cpassword,mobileno,email,Country_code;
    RadioButton farmer,generaluser, retailer;
    DatabaseReference reff;
    FirebaseAuth mAuth;
    User user;
    ProgressBar progressBar;
    FirebaseUser fUser;
    String UID,Category;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        name=(EditText)findViewById(R.id.name);
        password=(EditText)findViewById(R.id.password);
        cpassword=(EditText)findViewById(R.id.cpassword);
        Country_code=(EditText)findViewById(R.id.country_code);
        mobileno=(EditText)findViewById(R.id.mobileno);
        email=(EditText)findViewById(R.id.email);

        farmer=(RadioButton)findViewById(R.id.farmer);
        generaluser=(RadioButton)findViewById(R.id.generaluser);
        retailer=(RadioButton)findViewById(R.id.retailer);

        progressBar=(ProgressBar)findViewById(R.id.progressBar2);

        user=new User();
        reff= FirebaseDatabase.getInstance().getReference().child("User");
        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();
    }

    public void create_account(View view)
    {
        final String Name=name.getText().toString().trim();
        final String Password=password.getText().toString().trim();
        final String CPassword=cpassword.getText().toString().trim();
        String CountryCode=Country_code.getText().toString().trim();
        final String Mobile=mobileno.getText().toString().trim();
        final String Email=email.getText().toString().trim();
        if (farmer.isChecked()) {
            Category=farmer.getText().toString();
        } else if (generaluser.isChecked()) {
            Category=generaluser.getText().toString();
        } else if (retailer.isChecked()){
            Category=retailer.getText().toString();
        }else {
            Toast.makeText(SignUp.this,"Please select the category",Toast.LENGTH_SHORT).show();
        }
        if (Name.equals(""))
        {
            name.setError("Enter name");
            return;
        }
        else if (Email.equals(""))
        {
            email.setError("Enter Email ID");
            return;
        }
        else if (Password.equals(""))
        {
            password.setError("Enter Password");
            return;
        }
        else if (Password.length()<6)
        {
            password.setError("Password must be atleast 6 characters");
            return;
        }
        else if (CPassword.equals(""))
        {
            cpassword.setError("Enter Conform Password");
            return;
        }else if (CountryCode.equals(""))
        {
            Country_code.setError("Enter Country code");
            return;
        }
        else if (Mobile.equals(""))
        {
            mobileno.setError("Enter Mobile Number");
            return;
        }
        else if (Mobile.length()<10 || Mobile.length()>10)
        {
            mobileno.setError("Invalid Mobile Number");
            return;
        }
        else if (Password.equals(CPassword)) {
            CountryCode=Country_code.getText().toString();
            final String MobileNo=CountryCode+" "+Mobile;
            progressBar.setVisibility(View.VISIBLE);

            mAuth.createUserWithEmailAndPassword(Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>()
            {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task)
                {
                    if (task.isSuccessful()){
                         mAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>()
                         {
                             @Override
                             public void onComplete(@NonNull Task<Void> task)
                             {
                                if (task.isSuccessful())
                                {
                                    fUser=mAuth.getInstance().getCurrentUser();
                                    UID=fUser.getUid();

                                    User mUser = new User(Name,Password,MobileNo,Email,Category,UID);
                                    reff.child(UID).setValue(mUser)
                                            .addOnCompleteListener(new OnCompleteListener<Void>()
                                            {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task)
                                                {
                                                    if(task.isSuccessful())
                                                    {
                                                        Toast.makeText(getApplicationContext(),"Values stored successfully,Please check the mail for Verification",Toast.LENGTH_LONG).show();
                                                        /*Intent login=new Intent(SignUp.this,Login.class);
                                                        startActivity(login);*/
                                                        progressBar.setVisibility(View.GONE);

                                                        name.setText("");
                                                        password.setText("");
                                                        cpassword.setText("");
                                                        mobileno.setText("");
                                                        email.setText("");
                                                        farmer.setChecked(false);
                                                        generaluser.setChecked(false);
                                                        retailer.setChecked(false);
                                                    }
                                                }
                                            });
                                }
                                else
                                    {
                                        Toast.makeText(SignUp.this,"Error="+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                                        progressBar.setVisibility(View.GONE);
                                    }
                             }
                         });
                    }
                    else {
                        Toast.makeText(SignUp.this,"Error createUserWithEmailAndPassword="+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                        progressBar.setVisibility(View.GONE);
                    }
                }
            });
        }
        else
        {
            cpassword.setError("Not match with Password");
            return;
        }
    }
    public void login_page(View view)
    {
        Intent intent=new Intent(SignUp.this,Login.class);
        startActivity(intent);
        finish();
    }
}
