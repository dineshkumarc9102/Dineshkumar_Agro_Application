package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UserAddress extends AppCompatActivity {

    TextView t_Houseno,t_area,t_city,t_state,t_landmark,t_pincode,Latitude,Longitude;
    EditText e_Houseno,e_area,e_city,e_state,e_landmark,e_pincode;
    Button Save_address;
    String E_Houseno="",E_area="",E_city="",E_state="",E_landmark="",E_pincode="",latitude, longitude;
    DatabaseReference reference;
    FirebaseUser user;
    FirebaseAuth lAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_address);

        t_Houseno=(TextView)findViewById(R.id.textView_house_no);
        t_area=(TextView)findViewById(R.id.textView_area);
        t_city=(TextView)findViewById(R.id.textView_city);
        t_state=(TextView)findViewById(R.id.textView_state);
        t_landmark=(TextView)findViewById(R.id.textView_landmark);
        t_pincode=(TextView)findViewById(R.id.textView_pincode);

        Latitude=(TextView)findViewById(R.id.latitude);
        Longitude=(TextView)findViewById(R.id.longitude);

        e_Houseno=(EditText)findViewById(R.id.editText_house_no);
        e_area=(EditText)findViewById(R.id.editText_area);
        e_city=(EditText)findViewById(R.id.editText_city);
        e_state=(EditText)findViewById(R.id.editText_state);
        e_landmark=(EditText)findViewById(R.id.editText_landmark);
        e_pincode=(EditText)findViewById(R.id.editText_pincode);

        Save_address=(Button)findViewById(R.id.save_address);

        lAuth=FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();
        reference= FirebaseDatabase.getInstance().getReference().child("Address");

        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    if (dataSnapshot.child("houseno").exists())
                        e_Houseno.setText(dataSnapshot.child("houseno").getValue().toString());
                    if (dataSnapshot.child("area").exists())
                        e_area.setText(dataSnapshot.child("area").getValue().toString());
                    if (dataSnapshot.child("city").exists())
                        e_city.setText(dataSnapshot.child("city").getValue().toString());
                    if (dataSnapshot.child("state").exists())
                        e_state.setText(dataSnapshot.child("state").getValue().toString());
                    if (dataSnapshot.child("landmark").exists())
                        e_landmark.setText(dataSnapshot.child("landmark").getValue().toString());
                    if (dataSnapshot.child("pincode").exists())
                        e_pincode.setText(dataSnapshot.child("pincode").getValue().toString());
                    if (dataSnapshot.child("latitude").exists())
                        Latitude.setText(dataSnapshot.child("latitude").getValue().toString());
                    if (dataSnapshot.child("longitude").exists())
                        Longitude.setText(dataSnapshot.child("longitude").getValue().toString());

                    Save_address.setText("UPDATE");
                    e_Houseno.setSelection(e_Houseno.getText().length());
                    e_area.setSelection(e_area.getText().length());
                    e_city.setSelection(e_city.getText().length());
                    e_state.setSelection(e_state.getText().length());
                    e_landmark.setSelection(e_landmark.getText().length());
                    e_pincode.setSelection(e_pincode.getText().length());;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Save_address.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                E_Houseno = e_Houseno.getText().toString().trim();
                E_area = e_area.getText().toString().trim();
                E_city = e_city.getText().toString().trim();
                E_state = e_state.getText().toString().trim();
                E_landmark = e_landmark.getText().toString().trim();
                E_pincode = e_pincode.getText().toString().trim();
                latitude = Latitude.getText().toString().trim();
                longitude = Longitude.getText().toString().trim();

                if (E_Houseno.equals("")){
                    e_Houseno.setError("Enter House no");
                    return;
                }
                else if (E_area.equals("")){
                    e_area.setError("Enter area");
                    return;
                }
                else if (E_city.equals("")){
                    e_city.setError("Enter city");
                    return;
                }
                else if (E_state.equals("")){
                    e_state.setError("Enter state");
                    return;
                }
                else if (E_pincode.equals("")){
                    e_pincode.setError("Enter Pincode");
                    return;
                } else {
                    final String UID=user.getUid();
                    Database_Address address = new Database_Address(E_Houseno, E_area, E_city, E_state, E_landmark, E_pincode,latitude, longitude,UID);
                    reference.child(UID).setValue(address).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(getApplicationContext(), "Address Added Successfully.......", Toast.LENGTH_LONG).show();
                            } else {
                                Toast.makeText(getApplicationContext(), "Address Not Added ..." + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });
    }
}
