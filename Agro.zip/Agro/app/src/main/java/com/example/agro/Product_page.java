package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class Product_page extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    DatabaseReference reference,reff,address_ref,reff_product,ref_user,ref_subscribe,ref_sub_farmer;
    TextView name,price,seller,description,quantity,stock,quantity2,qua_req1,upload_on;
    Button AddToCart,Buy,Save_subscribe;
    Spinner qua_req;
    String pname,pprice,uname,pseller,psellerid,pdescription,productId,typeOf,pImage,pquantity,pstock,pquantity2,Qua_req,newBal,uptime,UID;
    ImageView prImage;
    ProgressBar progressBar,progressBarCart;
    Database_Cart database_cart;
    FirebaseUser user;
    FirebaseAuth lAuth;
    int bal_stock,iquantity,Total,qua,iprice;
    String category,GrandTotal = null;
    Double disTotal = null, discount;
    LinearLayout Subscribe_layout,Subscribe_layout2,BuyLayout,WeekLayout,Discount_layout;
    RadioButton Daily,Weekly;
    Switch Switch_subscribe;
    CheckBox Sun,Mon,Tue,Wed,Thu,Fri,Sat;
    String sun,mon,tue,wed,thu,fri,sat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_page);

        name=(TextView)findViewById(R.id.product_name);
        price=(TextView)findViewById(R.id.product_price);
        seller=(TextView)findViewById(R.id.product_seller);
        description=(TextView)findViewById(R.id.product_description);
        quantity=(TextView)findViewById(R.id.product_quantity);
        prImage=(ImageView)findViewById(R.id.imageView4);
        progressBar=(ProgressBar)findViewById(R.id.progressBar3);
        progressBarCart=(ProgressBar)findViewById(R.id.progressCart);
        stock=(TextView)findViewById(R.id.product_stock);
        quantity2=(TextView)findViewById(R.id.product_quantity2);
        qua_req=(Spinner) findViewById(R.id.quantity_req);
        qua_req1=(TextView)findViewById(R.id.quantity_req1);
        upload_on=(TextView)findViewById(R.id.upload_on);
        AddToCart=(Button)findViewById(R.id.add_cart);
        Buy=(Button)findViewById(R.id.buy);
        Subscribe_layout=(LinearLayout)findViewById(R.id.subscribe_layout);
        Subscribe_layout2=(LinearLayout)findViewById(R.id.subscribe_layout2);
        Daily=(RadioButton)findViewById(R.id.daily);
        Weekly=(RadioButton)findViewById(R.id.weekly);
        Save_subscribe=(Button)findViewById(R.id.save_subscribe);
        Switch_subscribe=(Switch)findViewById(R.id.switch_subscribe);
        BuyLayout=(LinearLayout)findViewById(R.id.buyLayout);
        WeekLayout=(LinearLayout)findViewById(R.id.weekLayout);
        Discount_layout=(LinearLayout)findViewById(R.id.discount_layout);

        Sun=(CheckBox)findViewById(R.id.sun);
        Mon=(CheckBox)findViewById(R.id.mon);
        Tue=(CheckBox)findViewById(R.id.tue);
        Wed=(CheckBox)findViewById(R.id.wed);
        Thu=(CheckBox)findViewById(R.id.thu);
        Fri=(CheckBox)findViewById(R.id.fri);
        Sat=(CheckBox)findViewById(R.id.sat);

        lAuth = FirebaseAuth.getInstance();
        user=lAuth.getCurrentUser();
        UID=user.getUid();

        database_cart=new Database_Cart();
        reff=FirebaseDatabase.getInstance().getReference().child("Cart");

        final Intent intent=getIntent();
        productId=intent.getStringExtra("imageAddress");

        typeOf=intent.getStringExtra("typeOf");
        reference= FirebaseDatabase.getInstance().getReference().child("Product_farmers");

        reference.child(typeOf).child(productId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()) {
                    pname = dataSnapshot.child("pname").getValue().toString();
                    pprice = dataSnapshot.child("pprice").getValue().toString();
                    pseller = dataSnapshot.child("pseller").getValue().toString();
                    psellerid = dataSnapshot.child("sellerid").getValue().toString();
                    pdescription = dataSnapshot.child("pdescription").getValue().toString();
                    pquantity = dataSnapshot.child("pquantity").getValue().toString();
                    pstock = dataSnapshot.child("pstock").getValue().toString();
                    pquantity2 = dataSnapshot.child("pquantity2").getValue().toString();
                    uptime=dataSnapshot.child("upTime").getValue().toString();
                    pImage = dataSnapshot.child("imageAdress").getValue().toString();

                    bal_stock = Integer.parseInt(pstock);

                    Picasso.get()
                            .load(pImage)
                            .resize(1000, 1000)
                            .centerCrop()
                            .into(prImage);

                    progressBar.setVisibility(View.GONE);

                    name.setText(pname);
                    price.setText("₹" + pprice);
                    quantity.setText("per/" + pquantity);
                    seller.setText(pseller);
                    description.setText(pdescription);
                    stock.setText(pstock);
                    quantity2.setText(pquantity2);
                    upload_on.setText(uptime);

                    if (bal_stock == 0) {
                        AddToCart.setEnabled(false);
                        AddToCart.setBackgroundColor(Color.parseColor("#DFD5D5"));
                        Buy.setEnabled(false);
                        Buy.setBackgroundColor(Color.parseColor("#DFD5D5"));
                        qua_req.setEnabled(false);
                        qua_req.setVisibility(View.GONE);
                        qua_req1.setText("*Out of Stock");
                        qua_req1.setTextSize(20);
                        qua_req1.setTextColor(Color.parseColor("red"));
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Product_page.this,"Data not fetched.....",Toast.LENGTH_SHORT);
                progressBar.setVisibility(View.GONE);
            }
        });

        ref_user=FirebaseDatabase.getInstance().getReference().child("User");
        ref_user.child(user.getUid()).addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                if (dataSnapshot.exists()) {
                    category = dataSnapshot.child("category").getValue().toString();
                    uname=dataSnapshot.child("name").getValue().toString();
                }

                if (category.equals("Farmer")) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(Product_page.this,R.array.general_user,android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    qua_req.setAdapter(adapter);
                    qua_req.setOnItemSelectedListener(Product_page.this);
                }
                else if (category.equals("General User")) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(Product_page.this,R.array.general_user,android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    qua_req.setAdapter(adapter);
                    qua_req.setOnItemSelectedListener(Product_page.this);
                }
                else if (category.equals("Retailer/Hotels")) {
                    ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(Product_page.this,R.array.retailer,android.R.layout.simple_spinner_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    qua_req.setAdapter(adapter);
                    qua_req.setOnItemSelectedListener(Product_page.this);

                    Discount_layout.setVisibility(View.VISIBLE);
                    Subscribe_layout.setVisibility(View.VISIBLE);
                    ref_sub_farmer=FirebaseDatabase.getInstance().getReference().child("Subscribers_farmer");
                    ref_subscribe=FirebaseDatabase.getInstance().getReference().child("Retailer_Subscribe");
                    ref_subscribe.child(user.getUid()).child(productId).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.exists()){
                                Switch_subscribe.setChecked(true);
                                if (dataSnapshot.child("sub_Sun").exists())
                                    sun=dataSnapshot.child("sub_Sun").getValue().toString(); else sun="No";
                                if (dataSnapshot.child("sub_Mon").exists())
                                    mon=dataSnapshot.child("sub_Mon").getValue().toString(); else mon="No";
                                if (dataSnapshot.child("sub_Tue").exists())
                                    tue=dataSnapshot.child("sub_Tue").getValue().toString(); else tue="No";
                                if (dataSnapshot.child("sub_Wed").exists())
                                    wed=dataSnapshot.child("sub_Wed").getValue().toString(); else wed="No";
                                if (dataSnapshot.child("sub_Thu").exists())
                                    thu=dataSnapshot.child("sub_Thu").getValue().toString(); else thu="No";
                                if (dataSnapshot.child("sub_Fri").exists())
                                    fri=dataSnapshot.child("sub_Fri").getValue().toString(); else fri="No";
                                if (dataSnapshot.child("sub_Sat").exists())
                                    sat=dataSnapshot.child("sub_Sat").getValue().toString(); else sat="No";

                                if (sun.equals("Yes") && mon.equals("Yes") && tue.equals("Yes") && wed.equals("Yes") && thu.equals("Yes") && fri.equals("Yes") && sat.equals("Yes")){
                                    Daily.setChecked(true);
                                }
                                else {
                                    Weekly.setChecked(true);
                                    if (sun.equals("Yes") ) Sun.setChecked(true);
                                    if (mon.equals("Yes") ) Mon.setChecked(true);
                                    if (tue.equals("Yes") ) Tue.setChecked(true);
                                    if (wed.equals("Yes") ) Wed.setChecked(true);
                                    if (thu.equals("Yes") ) Thu.setChecked(true);
                                    if (fri.equals("Yes") ) Fri.setChecked(true);
                                    if (sat.equals("Yes") ) Sat.setChecked(true);
                                }
                            }

                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                            Toast.makeText(Product_page.this,"Data not fetched.....in user",Toast.LENGTH_SHORT);
                        }
                    });

                    Switch_subscribe.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            if (isChecked){
                                Subscribe_layout2.setVisibility(View.VISIBLE);

                                Weekly.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                                    @Override
                                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                                        if (Weekly.isChecked()){
                                            WeekLayout.setVisibility(View.VISIBLE);
                                        }
                                        else{
                                            WeekLayout.setVisibility(View.GONE);
                                        }
                                    }
                                });

                                Save_subscribe.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        Subscribe();
                                    }
                                });
                            }
                            else {
                                Subscribe_layout2.setVisibility(View.GONE);
                                BuyLayout.setVisibility(View.VISIBLE);
                                if (Daily.isChecked() || Weekly.isChecked())
                                {
                                    Unsubscribe();
                                }
                            }
                        }
                    });
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"Something Went Wrong......",Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void Subscribe() {
        if (Daily.isChecked()){
            sun="Yes";
            mon="Yes";
            tue="Yes";
            wed="Yes";
            thu="Yes";
            fri="Yes";
            sat="Yes";
        }
        else if (Weekly.isChecked()){
            if (Sun.isChecked()) sun="Yes"; else sun="No";
            if (Mon.isChecked()) mon="Yes"; else mon="No";
            if (Tue.isChecked()) tue="Yes"; else tue="No";
            if (Wed.isChecked()) wed="Yes"; else wed="No";
            if (Thu.isChecked()) thu="Yes"; else thu="No";
            if (Fri.isChecked()) fri="Yes"; else fri="No";
            if (Sat.isChecked()) sat="Yes"; else sat="No";
        }

        if (Daily.isChecked() || Weekly.isChecked()) {
            if (Daily.isChecked() || Sun.isChecked() || Mon.isChecked() || Tue.isChecked() || Wed.isChecked() || Thu.isChecked() || Fri.isChecked() || Sat.isChecked()) {
                final Database_retailer_Schedule database_retailer_schedule = new Database_retailer_Schedule(uname, pname, pprice, Qua_req, pquantity, typeOf, pseller, psellerid, sun, mon, tue, wed, thu, fri, sat, productId, pImage,UID);
                ref_subscribe.child(user.getUid()).child(productId).setValue(database_retailer_schedule).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            ref_sub_farmer.child(psellerid).child(productId).setValue(database_retailer_schedule);
                            Toast.makeText(getApplicationContext(), "Schedule added Successfully", Toast.LENGTH_SHORT).show();
                            progressBarCart.setVisibility(View.GONE);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Schedule is failed..." + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                            progressBarCart.setVisibility(View.GONE);
                        }
                    }
                });

                /*Database_retailer_Schedule retailer_schedule_farmer = new Database_retailer_Schedule(pname, pprice, Qua_req, pquantity, typeOf, pseller, psellerid, sun, mon, tue, wed, thu, fri, sat, productId, pImage,UID);
                ref_sub_farmer.child(psellerid).child(productId).setValue(retailer_schedule_farmer);*/
            }
            else {
                Toast.makeText(getApplicationContext(), "Please select a day", Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(getApplicationContext(), "Please select daily or weekly", Toast.LENGTH_SHORT).show();
        }
    }

    private void Unsubscribe() {
        ref_subscribe.child(user.getUid()).child(productId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){
                    ref_sub_farmer.child(psellerid).child(productId).removeValue();

                    Toast.makeText(getApplicationContext(), "Unsubscribed Successfully", Toast.LENGTH_SHORT).show();
                    progressBarCart.setVisibility(View.GONE);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Unsubscribe is failed..." + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    progressBarCart.setVisibility(View.GONE);
                }
            }
        });
    }

    public void add_to_cart(View view) {
            iquantity = Integer.parseInt(Qua_req);
            if (iquantity <= bal_stock) {
                iquantity = Integer.parseInt(Qua_req);
                bal_stock = bal_stock - iquantity;
                newBal = bal_stock + "";

                progressBarCart.setVisibility(View.VISIBLE);

                String cartid=System.currentTimeMillis()+""+productId;
                database_cart = new Database_Cart(pname, pprice, pquantity, pdescription, pseller, psellerid,typeOf, newBal, pquantity2, Qua_req, uptime, pImage, productId,cartid,UID);
                reff.child(user.getUid()).child(cartid).setValue(database_cart).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getApplicationContext(), "Added to Cart", Toast.LENGTH_SHORT).show();
                            progressBarCart.setVisibility(View.GONE);
                        }
                        else {
                            Toast.makeText(getApplicationContext(), "Can't add to Cart" + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                            progressBarCart.setVisibility(View.GONE);
                        }
                    }
                });
                reff_product=FirebaseDatabase.getInstance().getReference().child("Product_farmers");
                String P_permission="approved";
                Database_products product = new Database_products(pname, pprice, pquantity, pdescription, pseller,psellerid, typeOf,newBal,pquantity2,uptime, pImage,productId,P_permission);
                reff_product.child(typeOf).child(productId).setValue(product).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){ }
                        else {
                            Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
            }
            else {
                Toast.makeText(getApplicationContext(), "Your requirement is more than available stock", Toast.LENGTH_SHORT).show();
            }
    }

    public void Buy_now(View v) {
            iquantity=Integer.parseInt(Qua_req);
            if (iquantity <= bal_stock) {
                progressBarCart.setVisibility(View.VISIBLE);
            iquantity = Integer.parseInt(Qua_req);
            int Bal_stock = bal_stock - iquantity;
            newBal = Bal_stock + "";
            progressBarCart.setVisibility(View.GONE);

            address_ref = FirebaseDatabase.getInstance().getReference().child("Address");
            address_ref.child(user.getUid()).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.child("houseno").exists() ) {
                        iprice = Integer.parseInt(pprice);
                        qua = Integer.parseInt(Qua_req);
                        Total = qua * iprice;
                        GrandTotal=Total+"";

                        if (iquantity > 10) {
                            discount = Total * 0.10;
                            disTotal = Total - discount;
                            GrandTotal=disTotal+"";
                        }
                        else if (iquantity > 50) {
                            discount = Total * 0.15;
                            disTotal = Total - discount;
                            GrandTotal=disTotal+"";
                        }

                        Intent placeorder = new Intent(Product_page.this, Order_summary.class);
                        placeorder.putExtra("Total", GrandTotal);
                        placeorder.putExtra("purchase_flag", "single");
                        placeorder.putExtra("pname", pname);
                        placeorder.putExtra("pprice", pprice);
                        placeorder.putExtra("Qua_req", Qua_req);
                        placeorder.putExtra("pquantity", pquantity);
                        placeorder.putExtra("pseller", pseller);
                        placeorder.putExtra("psellerid", psellerid);
                        placeorder.putExtra("productId", productId);
                        placeorder.putExtra("pdescription", pdescription);
                        placeorder.putExtra("pquantity2", pquantity2);
                        placeorder.putExtra("pImage", pImage);
                        placeorder.putExtra("pTypeof", typeOf);
                        placeorder.putExtra("NewStock", newBal);
                        placeorder.putExtra("UpTime", uptime);
                        startActivity(placeorder);
                    }
                    else {
                        Intent address = new Intent(Product_page.this, UserAddress.class);
                        startActivity(address);
                        finish();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(Product_page.this, "Data not fetched.....", Toast.LENGTH_SHORT);
                }
            });
            }
            else {
                Toast.makeText(getApplicationContext(), "Your requirement is more than available stock", Toast.LENGTH_SHORT).show();
            }
    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        Qua_req=parent.getItemAtPosition(position).toString();
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }
}