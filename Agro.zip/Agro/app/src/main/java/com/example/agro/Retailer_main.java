package com.example.agro;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Retailer_main extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout r_drawerLayout;
    ActionBarDrawerToggle r_actionBarDrawerToggle;
    Toolbar r_toolbar;
    NavigationView r_navigationView;
    FragmentManager r_fragmentManager;
    FragmentTransaction r_fragmentTransaction;
    FirebaseAuth lAuth;
    DatabaseReference reference;
    String U_name;
    TextView UserName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.retailer_main);

        r_toolbar=findViewById(R.id.toolbar_retailer);
        setSupportActionBar(r_toolbar);
        r_drawerLayout=findViewById(R.id.drawer_retailer);
        r_navigationView=findViewById(R.id.navigationView_retailer);
        r_navigationView.setNavigationItemSelectedListener(this);

        View uView= r_navigationView.getHeaderView(0);
        UserName=(TextView)uView.findViewById(R.id.myname);

        lAuth = FirebaseAuth.getInstance();
        reference= FirebaseDatabase.getInstance().getReference().child("User");
        reference.child(lAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.child("name").exists()) {
                    U_name = dataSnapshot.child("name").getValue().toString();
                    UserName.setText(U_name);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(),"Data not fetched.....name",Toast.LENGTH_LONG).show();
            }
        });

        r_actionBarDrawerToggle=new ActionBarDrawerToggle(this,r_drawerLayout,r_toolbar,R.string.open,R.string.close);
        r_drawerLayout.addDrawerListener(r_actionBarDrawerToggle);
        r_actionBarDrawerToggle.setDrawerIndicatorEnabled(true);
        r_actionBarDrawerToggle.syncState();

        //load default fragment

        r_fragmentManager = getSupportFragmentManager();
        r_fragmentTransaction=r_fragmentManager.beginTransaction();
        r_fragmentTransaction.add(R.id.fragment_container_retailer,new Home());
        r_fragmentTransaction.commit();
    }
    public boolean loadFrag(Fragment fragment){
        if (fragment != null){
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container_retailer,fragment).
                    commit();
            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        r_drawerLayout.closeDrawer(GravityCompat.START);
        Fragment fragment=null;
        switch (menuItem.getItemId()){
            case R.id.r_home:
                fragment = new Home();
                break;

            case R.id.r_subscribe:
                Intent subscribe=new Intent(Retailer_main.this,Hotel_Schedule.class);
                startActivity(subscribe);
                break;

            case R.id.r_cart:
                Intent cart=new Intent(Retailer_main.this,Cart.class);
                startActivity(cart);
                break;

            case R.id.r_myaccount:
                Intent r_acc=new Intent(Retailer_main.this,Account.class);
                startActivity(r_acc);
                break;

            case R.id.r_orderhistory:
                Intent orderhistory =new Intent(Retailer_main.this,Order_history.class);
                startActivity(orderhistory);
                break;

            case R.id.r_logout:
                AlertDialog.Builder logout=new AlertDialog.Builder(Retailer_main.this);
                logout.setTitle("Logout")
                        .setMessage("Do you want to Logout")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                Retailer_main.super.onBackPressed();
                                finish();
                            }
                        })
                        .setNegativeButton("No",null).show();
                break;
        }
        return loadFrag(fragment);
    }

    @Override
    public void onBackPressed()
    {
        AlertDialog.Builder back = new AlertDialog.Builder(Retailer_main.this);
        back.setTitle("Alert")
                .setMessage("Do you want to Exit")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Retailer_main.super.onBackPressed();
                    }
                })
                .setNegativeButton("No",null).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.product_menu,menu);
        MenuItem cart = menu.findItem(R.id.add_to_cart);

        MenuItem searchItem =menu.findItem(R.id.action_search);
        searchItem.setVisible(false);

        cart.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent c =new Intent(getApplicationContext(),Cart.class);
                startActivity(c);
                return false;
            }
        });
        return true;
    }

}
